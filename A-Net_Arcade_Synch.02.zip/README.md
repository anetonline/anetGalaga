# A-NET ARCADE — Synchronet JavaScript Arcade Launcher

A-NET Arcade is a small, extensible arcade launcher for Synchronet BBS written in JavaScript.
This package bundles four mini-games to start: A-NET Galaga, A-NET Pong, A-NET Frogger and A-NET Turtle Bridge.
By: StingRay — A-Net Online BBS
Website: https://a-net-online.lol - http://a-net.fyi

Version: 0.01

---

## What it is

A-NET Arcade is a launcher that displays a clean game menu and runs games located next to the launcher or in the BBS `xtrn` directory.
The launcher reads a `games.json` manifest so you can add games simply by editing the JSON — no code changes required.

Key features:
- Extensible games list via `games.json`
- Preferred in-directory `load()` execution (avoids bbs.exec "open" errors)
- Fallback to `bbs.exec` for games installed in `xtrn`
- Uses `dd_lightbar_menu.js` for a polished menu when available (text fallback included)
- Cross-platform — works on Synchronet under Windows and Linux
- Clean screen restore when returning from games

Included games (packaged):
- A-NET Galaga        (galaga.js)
- A-NET Pong          (pong.js)
- A-Net Frogger       (anet-frogger.js)
- A-NET Turtle Bridge (turtlebridge.js)

---

## Requirements

- Synchronet 3.19+ (Windows or Linux)
  - `dd_lightbar_menu.js` — nicer menu UI
  - `event-timer.js` — smoother timing/waits
  - `xtrn/scroller/scroller.js` — view ANSI scoreboard files - 
     From: Codefenix of Constructive Chaos BBS - https://ConChaos.synchro.net

Note: This is a Synchronet door (runs under Synchronet BBS). Not a Node.js app.

---

## Installation

1. Create a directory for the arcade on your BBS, for example:
   - Windows: `C:\sbbs\xtrn\anetarcade`
   - Linux: `/sbbs/xtrn/anetarcade`

2. Copy these files into that directory:
   - `A-NetArcade.js` (the launcher)
   - `games.json` (manifest) — included in package
   - the game scripts: `galaga.js`, `pong.js`, `anet-frogger.js` , `turtlebridge.js`

3. File permissions (Linux):
   - Ensure the Synchronet user can read/write the directory and created data subdirectories:
     - e.g. `chown -R sbbs:sbbs /sbbs/xtrn/anetarcade`
     - `chmod -R 755 /sbbs/xtrn/anetarcade`

4. (Optional) Add an External Program entry in SCFG if you want to run the launcher from the BBS menu:
   - Directory: path to the arcade folder
   - Command: `?A-NetArcade.js`
   - Menu text: `A-NET ARCADE`

---

## games.json format

The launcher reads `games.json` (in the same directory) to build the menu. Example:

```json
[
  { "id": "galaga",       "title": "A-NET Galaga",        "file": "galaga.js" },
  { "id": "pong",         "title": "A-NET Pong",          "file": "pong.js" },
  { "id": "frogger",      "title": "A-NET Frogger",       "file": "anet-frogger.js" },
  { "id": "turtlebridge", "title": "A-NET Turtle Bridge", "file": "turtlebridge.js" }
]
