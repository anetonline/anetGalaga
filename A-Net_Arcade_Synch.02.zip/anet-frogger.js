/*
  A-NET FROGGER (anet-frogger.js) - Version: .03 for Synchronet BBS
   By: StingRay of A-Net Online BBS - http://a-net.fyi - https://a-net-online.lol
   bbs.a-net.online - telnet:1337 ssh:1338 rlogin:1339
   Add to A-Net Arcade by copying into the A-Net Arcade directory & adding to games.json
   Can also be run solo - External Programs - command: ?anetfrogger.js
*/

load("sbbsdefs.js");

try { require("dd_lightbar_menu.js", "DDLightbarMenu"); } catch(e) { /* optional */ }
var EventTimerAvailable = false;
try { load("event-timer.js"); EventTimerAvailable = true; } catch(e){ EventTimerAvailable = false; }

/* ---------------- Paths & Dirs ---------------- */
var rawBase = (typeof js !== "undefined" && js.exec_dir) ? js.exec_dir : ".";
var SEP = (rawBase.indexOf("/") !== -1) ? "/" : "\\";
if (rawBase.slice(-1) !== SEP) rawBase += SEP;
var BASE_DIR = rawBase;
var DATA_DIR = BASE_DIR + "anet-frogger_data" + SEP;
var PLAYERS_DIR = DATA_DIR + "players" + SEP;
var LEADER_DIR = DATA_DIR + "leaderboards" + SEP;
var ART_DIR = BASE_DIR + "art" + SEP;

function ensureDirs(){ var dirs=[DATA_DIR,PLAYERS_DIR,LEADER_DIR,ART_DIR]; for(var i=0;i<dirs.length;i++){ try{ if(typeof file_exists==="function" && !file_exists(dirs[i])) mkdir(dirs[i]); }catch(e){} } }
ensureDirs();

/* ---------------- Utilities ---------------- */
function readJsonFile(fp){ try{ if(typeof file_exists==="function" && !file_exists(fp)) return null; var f=new File(fp); if(!f.open("r")) return null; var raw=f.readAll().join(""); f.close(); return JSON.parse(raw);}catch(e){return null;} }
function writeJsonFile(fp,obj){ try{ var f=new File(fp); if(!f.open("w")) return false; f.write(JSON.stringify(obj,null,2)); f.close(); return true;}catch(e){return false;} }
function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
function repeatString(s,n){ var r=""; for(var i=0;i<n;i++) r+=s; return r; }
function fmtPadRight(s,len){ s = String(s||""); while(s.length < len) s += " "; return s.substring(0,len); }

/* ---------------- Colors / ANSI ---------------- */
var ESC = "\x1b[";
var ANSI_RESET = ESC + "0m";
var ANSI_BOLD = ESC + "1m";
var C_WHITE  = ESC + "1;37m";
var C_GREEN  = ESC + "1;32m";
var C_RED    = ESC + "1;31m";
var C_YELLOW = ESC + "1;33m";
var C_CYAN   = ESC + "1;36m";
var C_BLUE   = ESC + "1;34m";

/* ---------------- Persistence ---------------- */
function playerFile(n){ return PLAYERS_DIR + "player-" + n + ".json"; }
function loadPlayer(n){ var j = readJsonFile(playerFile(n)); if(!j) return { userNumber:n, alias:(typeof user!=="undefined"&&user&&user.alias)?user.alias:"Guest", bestScore:0, totalPlays:0, lives:3, achievements:{} }; j.alias = j.alias || ((typeof user !== "undefined" && user && user.alias) ? user.alias : "Guest"); j.lives = (typeof j.lives === "number") ? j.lives : 3; j.achievements = j.achievements || {}; return j; }
function savePlayer(n,obj){ return writeJsonFile(playerFile(n), obj); }

var LB_FILE = LEADER_DIR + "frogger-leaderboard.json";
function loadLeaderboard(){ var j = readJsonFile(LB_FILE); return (j && Array.isArray(j)) ? j : []; }
function saveLeaderboard(arr){ return writeJsonFile(LB_FILE, arr); }

/* ---------------- Config & Globals ---------------- */
var TICK_HZ = 12;
var FRAME_MS = Math.floor(1000 / TICK_HZ);
var START_LIVES = 3;
var WIDTH = console.screen_columns || 80;
var HEIGHT = console.screen_rows || 24;
var MAX_HOME_SLOTS = 5;
var MAX_LEVEL = 20;

/* ---------------- Invulnerability setting ---------------- */
var INVUL_MS = 350; // ms of invulnerability after a move/reset/level-up

/* ---------------- Input normalization ---------------- */
function readNormalizedKey(timeoutMillis){
  timeoutMillis = (typeof timeoutMillis === "number") ? timeoutMillis : 1;
  var k = console.inkey(K_NONE, timeoutMillis);
  if(!k) return null;
  try{
    if(typeof KEY_UP !== "undefined" && k === KEY_UP) return "UP";
    if(typeof KEY_DOWN !== "undefined" && k === KEY_DOWN) return "DOWN";
    if(typeof KEY_LEFT !== "undefined" && k === KEY_LEFT) return "LEFT";
    if(typeof KEY_RIGHT !== "undefined" && k === KEY_RIGHT) return "RIGHT";
  }catch(e){}
  var s = String(k);
  if(s === "\x1b"){
    var n1 = console.inkey(K_NONE,20); if(!n1) return "ESC"; s += String(n1);
    var n2 = console.inkey(K_NONE,20); if(n2) s += String(n2);
    if(s === "\x1b[A" || s === "\x1bOA") return "UP";
    if(s === "\x1b[B" || s === "\x1bOB") return "DOWN";
    if(s === "\x1b[C" || s === "\x1bOC") return "RIGHT";
    if(s === "\x1b[D" || s === "\x1bOD") return "LEFT";
    return null;
  }
  return s.toUpperCase();
}

/* ---------------- Difficulty chooser ---------------- */
function chooseDifficulty(){
  var choices = [
    { id: "Easy", label: "Easy - gentler speeds/density", speedMult: 0.90, densityMult: 0.85 },
    { id: "Medium", label: "Medium - standard", speedMult: 1.00, densityMult: 1.00 },
    { id: "Hard", label: "Hard - faster & slightly denser", speedMult: 1.12, densityMult: 1.12 }
  ];

  if(typeof DDLightbarMenu !== "undefined"){
    var boxW = Math.min(56, WIDTH - 10);
    var boxH = choices.length + 4;
    var left = Math.floor((WIDTH - boxW) / 2) + 1;
    var top = Math.floor((HEIGHT - boxH) / 2) + 1;
    var m = new DDLightbarMenu(left, top, boxW, boxH);
    for(var i=0;i<choices.length;i++) m.Add(choices[i].label, i+1);
    m.colors.itemColor = "\x01k\x01h";
    m.colors.selectedItemColor = "\x01c\x01h";
    m.AddAdditionalQuitKeys("qQ");
    m.borderEnabled = true;
    var v = m.GetVal();
    if(!v) return choices[1];
    return choices[parseInt(v,10)-1];
  } else {
    console.clear();
    console.gotoxy(3,3);
    console.print("Choose Difficulty:\r\n\r\n");
    for(var j=0;j<choices.length;j++) console.print((j+1)+") " + choices[j].label + "\r\n");
    console.gotoxy(1, HEIGHT); console.print("Choose [1-3]: ");
    var c = console.getkey();
    if(!c) return choices[1];
    var idx = parseInt(c,10) - 1;
    if(idx < 0 || idx >= choices.length) return choices[1];
    return choices[idx];
  }
}

/* ---------------- ANSI scoreboard writer ---------------- */
function writeScoresAnsi(){
  try{
    var lb = loadLeaderboard();
    var lines = [];
    var now = new Date();
    lines.push(C_BLUE + ANSI_BOLD + "        A-NET FROGGER - LOCAL LEADERBOARD        " + ANSI_RESET);
    lines.push("");
    lines.push(C_WHITE + "Last Updated: " + now.toISOString().slice(0,10) + " " + now.toISOString().slice(11,19) + ANSI_RESET);
    lines.push("");
    lines.push(C_WHITE + fmtPadRight("Pos",4) + " " + fmtPadRight("Player",20) + " " + fmtPadRight("Score",7) + " " + fmtPadRight("Date",10) + ANSI_RESET);
    lines.push("");
    if(!lb || lb.length === 0){ lines.push(C_WHITE + "No scores recorded yet." + ANSI_RESET); lines.push(""); }
    else {
      for(var i=0;i<Math.min(lb.length,200);i++){
        var e=lb[i], pos=(i+1)+".";
        lines.push(C_WHITE + fmtPadRight(pos,4) + " " + fmtPadRight((e.alias||"Guest").toString().substring(0,20),20) + " " + fmtPadRight(String(e.score||0),7) + " " + fmtPadRight((e.date||"").slice(0,10),10) + ANSI_RESET);
      }
    }
    lines.push("");
    lines.push(C_CYAN + "Generated by A-NET FROGGER - " + (new Date()).toISOString() + ANSI_RESET);
    lines.push("");
    var content = lines.join("\r\n");
    var path = ART_DIR + "frogger-scores.ans";
    var f = new File(path);
    if(f.open("w")){ f.write(content); f.close(); }
  }catch(e){}
}

/* ---------------- Header ---------------- */
function drawHeader(){
    try{ console.clear(); }catch(e){}
    try{
        console.gotoxy(1,1);
        var title = "A-NET FROGGER";
        var pad = Math.max(0, Math.floor((WIDTH - title.length) / 2));
        console.print(ANSI_BOLD + C_BLUE + repeatString(" ", pad) + title + repeatString(" ", pad) + ANSI_RESET + "\r\n");
        console.gotoxy(1, HEIGHT - 1);
        console.print("\x01gUse arrows or WASD to move. P pause. Q quit.");
    }catch(e){}
}

/* ---------------- Game ---------------- */
function playFrogger(userNumber){
    ensureDirs();
    try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}

    var pdata = loadPlayer(userNumber);
    pdata.alias = pdata.alias || ((typeof user !== "undefined" && user && user.alias) ? user.alias : "Guest");

    // local run state
    var gameLives = START_LIVES;
    var gameScore = 0;

    // difficulty
    var difficulty = chooseDifficulty() || { id:"Medium", speedMult:1.0, densityMult:1.0 };
    var diffSpeedMult = difficulty.speedMult;
    var diffDensityMult = difficulty.densityMult;

    // Field geometry
    var fieldWidth = Math.min(50, Math.max(30, Math.floor(WIDTH * 0.7)));
    var fieldLeft = Math.floor((WIDTH - fieldWidth) / 2) + 1;
    var fieldTop = 4;
    var fieldHeight = Math.min(HEIGHT - 8, 16);
    var fieldRight = fieldLeft + fieldWidth - 1;
    var fieldBottom = fieldTop + fieldHeight - 1;

    // Layout
    var homeRow = fieldTop;
    var topRiverRows = 2;
    var riverRows = 3;
    var midSafeRow = homeRow + 1 + topRiverRows + riverRows;
    var roadRows = 4;
    var bottomBankRow = midSafeRow + roadRows + 1;
    if(bottomBankRow > fieldBottom) bottomBankRow = fieldBottom;

    var lanes = [];
    lanes.push({ type: "home", y: homeRow });
    for(var r=0; r<topRiverRows+riverRows; r++) lanes.push({ type: "river", y: homeRow + 1 + r });
    lanes.push({ type: "safe", y: midSafeRow });
    for(var r=0; r<roadRows; r++) lanes.push({ type: "road", y: midSafeRow + 1 + r });
    lanes.push({ type: "bank", y: bottomBankRow });

    var cols = fieldWidth;

    var homeSlots = [];
    var slotGap = Math.floor(cols / (MAX_HOME_SLOTS + 1));
    for(var s=1; s<=MAX_HOME_SLOTS; s++){
        var cx = fieldLeft + s*slotGap - 1;
        homeSlots.push({ x: cx, y: homeRow, filled: false });
    }

    var level = 1;
    function laneConfig(indexFromTop){
        var baseSpeed = (0.36 + (indexFromTop * 0.02)) * diffSpeedMult * (1 + (level - 1) * 0.03);
        var dir = (indexFromTop % 2 === 0) ? 1 : -1;
        var density = (0.09 + (indexFromTop * 0.01)) * diffDensityMult * (1 + (level - 1) * 0.02);
        return { speed: baseSpeed, dir: dir, density: clamp(density, 0.03, 0.45) };
    }

    var laneStates = [];
    var interactiveLaneIdx = 0;
    for(var li=0; li<lanes.length; li++){
        var L = lanes[li];
        if(L.type === "river" || L.type === "road"){
            var cfg = laneConfig(interactiveLaneIdx);
            laneStates.push({ type: L.type, y: L.y, speed: cfg.speed, dir: cfg.dir, density: cfg.density, entities: [] });
            interactiveLaneIdx++;
        } else laneStates.push({ type: L.type, y: L.y });
    }

    var nextEntityId = 1;
    function normalizeGlyphToLen(glyph, len){
        glyph = String(glyph || "");
        if(glyph.length === len) return glyph;
        if(glyph.length > len) return glyph.substring(0,len);
        while(glyph.length < len) glyph += glyph[glyph.length-1] || glyph[0] || "#";
        return glyph;
    }

    function spawnForLane(ls, offscreen, idx, total){
        offscreen = !!offscreen; idx = (typeof idx === "number")?idx:0; total = (typeof total==="number"&& total>0)?total:1;
        if(ls.type === "road"){
            var pick = Math.random();
            var len = (pick < 0.10) ? 4 : (pick < 0.45 ? 3 : 2);
            var glyph = (len === 4) ? "####" : (len === 3) ? "===" : "###";
            glyph = normalizeGlyphToLen(glyph,len);
            var color = C_RED;
            var x;
            if(offscreen){
                var spacing = Math.max(3, Math.floor(cols / (total+1)));
                if(ls.dir > 0) x = fieldLeft - (idx+1) * (len + spacing) - 6 - Math.floor(Math.random()*3);
                else x = fieldRight + (idx+1) * (len + spacing) + 6 + Math.floor(Math.random()*3);
            } else x = (ls.dir > 0) ? (fieldLeft - Math.random()*6 - len) : (fieldRight + Math.random()*6 + len);
            ls.entities.push({ id: nextEntityId++, x: Number(x), len: len, glyph: glyph, color: color, speed: ls.speed * (0.9 + Math.random()*0.3) });
        } else if(ls.type === "river"){
            var choice = Math.random();
            var x;
            if(offscreen){
                var spacing2 = Math.max(4, Math.floor(cols / (total+1)));
                if(choice < 0.25){
                    var len2 = 5, glyph2 = normalizeGlyphToLen("lllll",len2);
                    if(ls.dir > 0) x = fieldLeft - (idx+1)*(len2+spacing2) - 8 - Math.floor(Math.random()*4);
                    else x = fieldRight + (idx+1)*(len2+spacing2) + 8 + Math.floor(Math.random()*4);
                    ls.entities.push({ id: nextEntityId++, x: Number(x), len: len2, glyph: glyph2, color: C_YELLOW, speed: ls.speed * (0.75 + Math.random()*0.2) });
                } else if(choice < 0.6){
                    var len3 = 3, glyph3 = normalizeGlyphToLen("lll",len3);
                    if(ls.dir > 0) x = fieldLeft - (idx+1)*(len3+spacing2) - 6 - Math.floor(Math.random()*3);
                    else x = fieldRight + (idx+1)*(len3+spacing2) + 6 + Math.floor(Math.random()*3);
                    ls.entities.push({ id: nextEntityId++, x: Number(x), len: len3, glyph: glyph3, color: C_YELLOW, speed: ls.speed * (0.85 + Math.random()*0.2) });
                } else {
                    var len4 = 2, glyph4 = normalizeGlyphToLen("TT",len4);
                    if(ls.dir > 0) x = fieldLeft - (idx+1)*(len4+spacing2) - 5 - Math.floor(Math.random()*2);
                    else x = fieldRight + (idx+1)*(len4+spacing2) + 5 + Math.floor(Math.random()*2);
                    ls.entities.push({ id: nextEntityId++, x: Number(x), len: len4, glyph: glyph4, color: C_GREEN, speed: ls.speed * (0.95 + Math.random()*0.2) });
                }
            } else {
                if(choice < 0.25){ var len2b=5, glyph2b=normalizeGlyphToLen("lllll",len2b); x = (ls.dir>0)?(fieldLeft - Math.random()*8 - len2b):(fieldRight + Math.random()*8 + len2b); ls.entities.push({ id: nextEntityId++, x:Number(x), len:len2b, glyph:glyph2b, color:C_YELLOW, speed:ls.speed*(0.75+Math.random()*0.2)}); }
                else if(choice < 0.6){ var len3b=3, glyph3b=normalizeGlyphToLen("lll",len3b); x = (ls.dir>0)?(fieldLeft - Math.random()*8 - len3b):(fieldRight + Math.random()*8 + len3b); ls.entities.push({ id: nextEntityId++, x:Number(x), len:len3b, glyph:glyph3b, color:C_YELLOW, speed:ls.speed*(0.85+Math.random()*0.2)}); }
                else { var len4b=2, glyph4b=normalizeGlyphToLen("TT",len4b); x = (ls.dir>0)?(fieldLeft - Math.random()*8 - len4b):(fieldRight + Math.random()*8 + len4b); ls.entities.push({ id: nextEntityId++, x:Number(x), len:len4b, glyph:glyph4b, color:C_GREEN, speed:ls.speed*(0.95+Math.random()*0.2)}); }
            }
        }
    }

    var frog = { x: Math.floor((fieldLeft + fieldRight)/2), y: bottomBankRow, carriedBy: null, invulUntil: 0 };
    var lastMap = {};
    var HUD_LINE1 = 1, HUD_LINE2 = 2;

    function setInvulNow(){
        frog.invulUntil = Date.now() + INVUL_MS;
    }

    function drawStaticField(){
        for(var s=0; s<homeSlots.length; s++){
            var slot = homeSlots[s];
            console.gotoxy(slot.x, slot.y);
            if(slot.filled) console.print(C_GREEN + "[" + "F" + "]" + ANSI_RESET);
            else console.print(C_CYAN + "[" + " " + "]" + ANSI_RESET);
        }
    }

    function drawHud(){
        console.gotoxy(1, HUD_LINE1);
        var leftPart = ANSI_BOLD + C_WHITE + "Player: " + pdata.alias + "   Lives: " + gameLives + "   Score: " + gameScore + "   Level: " + level + "   Mode: " + difficulty.id + ANSI_RESET;
        console.print(leftPart);
        console.gotoxy(1, HUD_LINE2);
        console.print(C_YELLOW + "Use arrows or WASD to move. P pause. Q quit to menu." + ANSI_RESET);
    }

    function buildMap(){
        var map = {};
        for(var li=0; li<lanes.length; li++){
            var L = lanes[li];
            var y = L.y;
            if(L.type === "home" || L.type === "safe" || L.type === "bank"){
                for(var cx=fieldLeft; cx<=fieldRight; cx++) map[cx + "," + y] = { ch: " ", color: "" };
            } else if(L.type === "river"){
                for(var cx=fieldLeft; cx<=fieldRight; cx++) map[cx + "," + y] = { ch: "~", color: C_CYAN };
            } else if(L.type === "road"){
                for(var cx=fieldLeft; cx<=fieldRight; cx++) map[cx + "," + y] = { ch: "=", color: C_RED };
            }
        }

        for(var si=0; si<homeSlots.length; si++){
            var hs = homeSlots[si];
            map[hs.x + "," + hs.y] = { ch: hs.filled ? "F" : " ", color: hs.filled ? C_GREEN : C_CYAN };
        }

        for(var li2=0; li2<laneStates.length; li2++){
            var ls = laneStates[li2];
            if(ls.type !== "river" && ls.type !== "road") continue;
            for(var ei=0; ei<ls.entities.length; ei++){
                var ent = ls.entities[ei];
                if(!ent || typeof ent.x !== "number" || !isFinite(ent.x) || !ent.len || ent.len <= 0) continue;
                var base = Math.round(ent.x);
                for(var px=0; px<ent.len; px++){
                    var col = base + px;
                    if(col >= fieldLeft && col <= fieldRight){
                        var ch = (typeof ent.glyph === "string" && ent.glyph[px]) ? ent.glyph[px] : ent.glyph[0] || "#";
                        map[col + "," + ls.y] = { ch: ch, color: ent.color };
                    }
                }
            }
        }

        var fx = Math.round(frog.x), fy = Math.round(frog.y);
        if(fx >= fieldLeft && fx <= fieldRight && fy >= fieldTop && fy <= fieldBottom) map[fx + "," + fy] = { ch: "@", color: C_GREEN };

        return map;
    }

    function renderDiff(curMap){
        var union = {};
        for(var k in lastMap) union[k]=true;
        for(var k2 in curMap) union[k2]=true;
        for(var key in union){
            var last = lastMap[key];
            var cur  = curMap[key];
            if(!last && cur){
                var p = key.split(","); var ax=parseInt(p[0],10), ay=parseInt(p[1],10);
                try{ console.gotoxy(ax, ay); console.print((cur.color?cur.color:"") + cur.ch + ANSI_RESET); }catch(e){}
            } else if(last && !cur){
                var p2 = key.split(","); var ax2=parseInt(p2[0],10), ay2=parseInt(p2[1],10);
                try{
                    var lane = null;
                    for(var li=0; li<lanes.length; li++){ if(lanes[li].y === ay2) { lane = lanes[li]; break; } }
                    if(lane){
                        if(lane.type === "river") console.gotoxy(ax2, ay2), console.print(C_CYAN + "~" + ANSI_RESET);
                        else if(lane.type === "road") console.gotoxy(ax2, ay2), console.print(C_RED + "=" + ANSI_RESET);
                        else console.gotoxy(ax2, ay2), console.print(" ");
                    } else console.gotoxy(ax2, ay2), console.print(" ");
                }catch(e){}
            } else if(last && cur){
                if(last.ch !== cur.ch || last.color !== cur.color){
                    var p3 = key.split(","); var ax3=parseInt(p3[0],10), ay3=parseInt(p3[1],10);
                    try{ console.gotoxy(ax3, ay3); console.print((cur.color?cur.color:"") + cur.ch + ANSI_RESET); }catch(e){}
                }
            }
        }
        lastMap = curMap;
    }

    function resetFrog(){
        frog.x = Math.floor((fieldLeft + fieldRight)/2);
        frog.y = bottomBankRow;
        frog.carriedBy = null;
        setInvulNow();
    }

    function loseLife(reason){
        gameLives--;
        try{ console.beep(300,120); }catch(e){}
        console.gotoxy(1, HUD_LINE2+1);
        console.print(C_RED + "Ouch! " + (reason||"") + ANSI_RESET);
        mswait(600);
        console.gotoxy(1, HUD_LINE2+1); console.print(repeatString(" ", WIDTH));
        resetFrog();
        if(gameLives <= 0) return true;
        return false;
    }

    function levelUp(){
        level++;
        if(level > MAX_LEVEL) level = MAX_LEVEL;
        gameScore += 100 + (level * 10);
        // rebuild laneStates speeds/density for new level
        interactiveLaneIdx = 0;
        for(var li=0; li<lanes.length; li++){
            var L = lanes[li];
            if(L.type === "river" || L.type === "road"){
                var cfg = laneConfig(interactiveLaneIdx);
                laneStates[li].speed = cfg.speed;
                laneStates[li].dir = cfg.dir;
                laneStates[li].density = cfg.density;
                laneStates[li].entities = [];
                interactiveLaneIdx++;
            }
        }
        initialPopulate();
        resetFrog();
        console.gotoxy(1, HUD_LINE2+1);
        console.print(C_CYAN + "Level Up! Now entering Level " + level + ANSI_RESET);
        mswait(800);
        console.gotoxy(1, HUD_LINE2+1); console.print(repeatString(" ", WIDTH));
    }

    function playSound(type){
        try{
            switch(type){
                case "jump": console.beep(1200,30); break;
                case "score": console.beep(1400,60); break;
                case "hit": console.beep(300,120); break;
                case "win": console.beep(1600,200); break;
            }
        }catch(e){}
    }

    function initialPopulate(){
        for(var i=0;i<laneStates.length;i++){
            var ls = laneStates[i];
            if(ls.type !== "river" && ls.type !== "road") continue;
            var count = Math.max(1, Math.floor(Math.max(1, cols * ls.density) / 6));
            for(var c=0;c<count;c++) spawnForLane(ls, true, c, count);
        }
    }

    function findEntityById(ls, id){
        if(!ls || !ls.entities) return null;
        for(var i=0;i<ls.entities.length;i++) if(ls.entities[i].id === id) return ls.entities[i];
        return null;
    }

    function updateEntities(){
        var movementThisTick = {};
        for(var li=0; li<laneStates.length; li++){
            var ls = laneStates[li];
            if(ls.type !== "river" && ls.type !== "road") continue;
            if(Math.random() < ls.density) spawnForLane(ls, false);
            for(var ei=ls.entities.length-1; ei>=0; ei--){
                var ent = ls.entities[ei];
                if(!ent || typeof ent.x !== "number" || !isFinite(ent.x) || !ent.len || ent.len <= 0) { ls.entities.splice(ei,1); continue; }
                var dx = ent.speed * ls.dir;
                ent.x += dx;
                movementThisTick[li + ":" + ent.id] = dx;
                if(ls.dir > 0 && (ent.x - ent.len) > (fieldRight + 12)) ls.entities.splice(ei,1);
                else if(ls.dir < 0 && (ent.x + ent.len) < (fieldLeft - 12)) ls.entities.splice(ei,1);
            }
        }

        if(frog.carriedBy){
            var li = frog.carriedBy.laneIndex;
            var eid = frog.carriedBy.entId;
            if(typeof li === "number" && typeof eid === "number" && li >= 0 && li < laneStates.length){
                var host = laneStates[li];
                var ent = findEntityById(host, eid);
                if(ent){
                    var dx = movementThisTick[li + ":" + eid] || (ent.speed * (host.dir || 1));
                    frog.x = frog.x + dx;
                    if(frog.x < fieldLeft || frog.x > fieldRight) frog.carriedBy = null;
                } else frog.carriedBy = null;
            } else frog.carriedBy = null;
        }
    }

    // collision detection with invulnerability handling
    function checkFrogCollisions(){
        var fx = Math.round(frog.x);
        var fy = Math.round(frog.y);
        var now = Date.now();
        var invul = (frog.invulUntil && now < frog.invulUntil);

        // Immediate top-row crossing triggers level-up
        if(fy === homeRow){
            gameScore += 50;
            levelUp();
            return { type: "scored" };
        }

        for(var li=0; li<laneStates.length; li++){
            var ls = laneStates[li];
            if(ls.y !== fy) continue;

            if(ls.type === "road"){
                // if invulnerable, skip hit detection; but still clear carriedBy
                frog.carriedBy = null;
                if(invul) return { type: "ok" };
                for(var ei=0; ei<ls.entities.length; ei++){
                    var ent = ls.entities[ei];
                    if(!ent || typeof ent.x !== "number" || !isFinite(ent.x) || !ent.len) continue;
                    var left = Math.floor(ent.x);
                    var right = left + Math.max(0, ent.len - 1);
                    if(fx >= left && fx <= right){
                        var glyphIndex = fx - left;
                        var ch = (typeof ent.glyph === "string" && ent.glyph[glyphIndex]) ? ent.glyph[glyphIndex] : (typeof ent.glyph === "string" ? ent.glyph[0] : "#");
                        if(ch && ch !== " ") return { type: "hit", reason: "Hit by vehicle" };
                    }
                }
                return { type: "ok" };
            } else if(ls.type === "river"){
                var found = false, entFound = null;
                for(var ej=0; ej<ls.entities.length; ej++){
                    var e2 = ls.entities[ej];
                    if(!e2 || typeof e2.x !== "number" || !isFinite(e2.x) || !e2.len) continue;
                    var left2 = Math.floor(e2.x);
                    var right2 = left2 + Math.max(0, e2.len - 1);
                    if(fx >= left2 && fx <= right2){
                        var glyphIdx = fx - left2;
                        var ch2 = (typeof e2.glyph === "string" && e2.glyph[glyphIdx]) ? e2.glyph[glyphIdx] : (typeof e2.glyph === "string" ? e2.glyph[0] : "#");
                        if(ch2 && ch2 !== " "){
                            found = true; entFound = e2; break;
                        }
                    }
                }
                if(!found){
                    // if invulnerable, skip drowning; allow chance to be carried later
                    if(invul) { frog.carriedBy = null; return { type: "ok" }; }
                    frog.carriedBy = null;
                    return { type: "water", reason: "Fell in water" };
                } else {
                    frog.carriedBy = { laneIndex: li, entId: entFound.id };
                    return { type: "safe" };
                }
            } else {
                frog.carriedBy = null;
                return { type: "ok" };
            }
        }

        return { type: "ok" };
    }

    initialPopulate();
    resetFrog();

    drawHeader();
    drawStaticField();
    drawHud();
    var curMap = buildMap();
    renderDiff(curMap);

    try{ console.print("\x1b[?25l"); }catch(e){}

    var runningLoop = true;
    var lastFrame = Date.now();
    var acc = 0;
    try{
        while(bbs.online && !js.terminated && runningLoop){
            var now = Date.now();
            var dt = now - lastFrame; lastFrame = now;
            if(dt > 400) dt = 400;
            acc += dt;
            var steps = Math.floor(acc / FRAME_MS);
            if(steps > 6) steps = 6;
            for(var s=0;s<steps;s++){
                var k = readNormalizedKey(0);
                if(k){
                    if(k === "UP" || k === "W"){ frog.y = Math.max(homeRow, frog.y - 1); setInvulNow(); try{ console.beep(1200,30); }catch(e){} gameScore += 10; frog.carriedBy = null; drawHud(); }
                    else if(k === "DOWN" || k === "S"){ frog.y = Math.min(bottomBankRow, frog.y + 1); setInvulNow(); try{ console.beep(1200,30); }catch(e){} frog.carriedBy = null; }
                    else if(k === "LEFT" || k === "A"){ frog.x = Math.max(fieldLeft, frog.x - 1); setInvulNow(); try{ console.beep(1200,30); }catch(e){} frog.carriedBy = null; }
                    else if(k === "RIGHT" || k === "D"){ frog.x = Math.min(fieldRight, frog.x + 1); setInvulNow(); try{ console.beep(1200,30); }catch(e){} frog.carriedBy = null; }
                    else if(k === "P"){ console.gotoxy(1, HUD_LINE2+1); console.print(C_YELLOW + "Paused - press any key to resume" + ANSI_RESET); console.getkey(); console.gotoxy(1, HUD_LINE2+1); console.print(repeatString(" ", WIDTH)); drawHud(); }
                    else if(k === "Q" || k === "ESC"){ runningLoop = false; break; }
                }

                updateEntities();

                var res = checkFrogCollisions();
                if(res.type === "hit"){
                    var dead = loseLife(res.reason);
                    if(dead){ runningLoop = false; break; }
                } else if(res.type === "water"){
                    var dead2 = loseLife(res.reason);
                    if(dead2){ runningLoop = false; break; }
                } else if(res.type === "scored"){
                    // levelUp handled inside checkFrogCollisions when top row reached
                }

                acc -= FRAME_MS;
            }

            drawHud();
            var m = buildMap();
            renderDiff(m);

            if(EventTimerAvailable) { try{ et_wait(1); } catch(e){ mswait(1); } } else mswait(1);
        }
    } finally {
        try{ console.print("\x1b[?25h"); }catch(e){}
    }

    // Save results
    pdata.totalPlays = (pdata.totalPlays || 0) + 1;
    pdata.lives = gameLives;
    if(gameScore > (pdata.bestScore || 0)) pdata.bestScore = gameScore;
    pdata.score = gameScore;
    savePlayer(userNumber, pdata);

    try{
        var lb = loadLeaderboard();
        lb.push({ alias: pdata.alias, score: gameScore || 0, date: (new Date()).toISOString(), mode: difficulty.id });
        lb.sort(function(a,b){ return b.score - a.score; });
        while(lb.length > 200) lb.pop();
        saveLeaderboard(lb);
        writeScoresAnsi();
    }catch(e){}

    console.clear();
    console.print(ANSI_BOLD + C_BLUE + "===== FROGGER - GAME OVER =====" + ANSI_RESET + "\r\n\r\n");
    console.print("Player: " + pdata.alias + "\r\n");
    console.print("Score: " + (gameScore || 0) + "\r\n");
    console.print("Level reached: " + level + "\r\n");
    console.print("Lives remaining: " + (gameLives || 0) + "\r\n\r\n");

    var lbshow = loadLeaderboard();
    for(var i=0;i<Math.min(lbshow.length,5);i++){ var e = lbshow[i]; console.print((i+1)+". " + e.alias + " - " + e.score + " (" + (e.date||"").slice(0,10) + ") " + (e.mode ? "["+e.mode+"]" : "") + "\r\n"); }

    console.print("\r\nView full scoreboard? (Y/N) ");
    var k = console.getkey();
    if(k && String(k).toUpperCase() === "Y"){
        var scrollerPath = ART_DIR + "frogger-scores.ans";
        try{ bbs.exec('?../xtrn/scroller/scroller.js "' + scrollerPath + '" "A-NET FROGGER - LOCAL LEADERBOARD" top'); }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + scrollerPath + '" "A-NET FROGGER - LOCAL LEADERBOARD" top'); }catch(e2){} }
    }

}

/* ---------------- Menus ---------------- */
function showHighScores(){
    writeScoresAnsi();
    var scrollerPath = ART_DIR + "frogger-scores.ans";
    if(typeof file_exists==="function" && file_exists(scrollerPath)){
        try { bbs.exec('?../xtrn/scroller/scroller.js "' + scrollerPath + '" "A-NET FROGGER - LOCAL LEADERBOARD" top'); return; }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + scrollerPath + '" "A-NET FROGGER - LOCAL LEADERBOARD" top'); return; }catch(e2){} }
    }
    console.clear();
    console.print("FROGGER - Local Leaderboard\r\n\r\n");
    var lb = loadLeaderboard();
    if(!lb || lb.length === 0) console.print("No scores recorded yet.\r\n\r\n");
    else {
        for(var i=0;i<Math.min(lb.length,20);i++){
            var e = lb[i];
            console.print(fmtPadRight((i+1)+".",4) + fmtPadRight(e.alias,20) + fmtPadRight(String(e.score||0),8) + " " + (e.date||"").slice(0,10) + (e.mode ? " ["+e.mode+"]" : "") + "\r\n");
        }
        console.print("\r\n");
    }
    console.print("Press any key..."); console.getkey();
}

function showInstructions(){
    var lines = [
        "Frogger - Instructions",
        "",
        "Objective: Move your frog from the bottom bank across lanes of traffic",
        "and a river (use logs/turtles) to reach the top.",
        "",
        "Controls: arrows or WASD, P pause, Q quit.",
        "",
        "When you reach the top row you immediately start the next level.",
        "Short invulnerability is active for " + INVUL_MS + "ms after each move to",
        "prevent immediate drowning/hits due to rounding or fractional movement.",
        ""
    ];
    var path = ART_DIR + "frogger-instr.ans";
    try{
        var header = C_BLUE + ANSI_BOLD + "        A-NET FROGGER - Instructions        " + ANSI_RESET + "\r\n\r\n";
        var content = header + lines.join("\r\n") + "\r\n";
        var f = new File(path);
        if(f.open("w")){ f.write(content); f.close(); try{ bbs.exec('?../xtrn/scroller/scroller.js "' + path + '" "A-NET FROGGER - Instructions" top'); return; }catch(e){} }
    }catch(e){}
    console.clear();
    for(var i=0;i<lines.length;i++) console.print(lines[i] + "\r\n");
    console.print("\r\nPress any key to continue...\r\n");
    console.getkey();
}

function showMainMenu(){
    drawHeader();
    if(typeof DDLightbarMenu !== "undefined"){
        var menu = new DDLightbarMenu(5, 3, Math.min(WIDTH-10,60), Math.min(HEIGHT-6,12));
        menu.Add("Play Frogger", 1);
        menu.Add("Instructions", 2);
        menu.Add("High Scores", 3);
        menu.Add("Quit", 4);
        menu.colors.itemColor = "\x01k\x01h";
        menu.colors.selectedItemColor = "\x01c\x01h";
        menu.colors.borderColor = "\x01c";
        menu.AddAdditionalQuitKeys("qQ");
        menu.borderEnabled = true;
        menu.scrollbarEnabled = true;
        return menu.GetVal();
    } else {
        console.gotoxy(4,4); console.print("1) Play Frogger");
        console.gotoxy(4,5); console.print("2) Instructions");
        console.gotoxy(4,6); console.print("3) High Scores");
        console.gotoxy(4,7); console.print("4) Quit");
        console.gotoxy(1, HEIGHT); console.print("Choose [1-4]: ");
        var c = console.getkey();
        return c;
    }
}

/* ---------------- Main ---------------- */
function main(){
    ensureDirs();
    try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}
    while(!js.terminated){
        var v = showMainMenu(); if(!v) break;
        var choice = (typeof v === "string") ? parseInt(v,10) : parseInt(v,10);
        var userNumber = (typeof user !== "undefined" && user && user.number) ? user.number : 9999;
        if(choice === 1) playFrogger(userNumber);
        else if(choice === 2) showInstructions();
        else if(choice === 3) showHighScores();
        else break;
    }
}

try{ main(); }catch(err){ try{ console.print("\r\nFatal error: " + (err && err.toString ? err.toString() : String(err)) + "\r\n"); }catch(e){} }