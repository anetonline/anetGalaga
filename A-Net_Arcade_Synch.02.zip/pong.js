/*
  A-Net PONG (pong.js) Synchronet v.02 By: StingRay of A-Net Online BBS
  - Single-player: left paddle = arrows (Up/Down). Right paddle = AI
  - Two-player local: left = arrows, right = W/S.
  - Multiplayer host/guest: host polls local keys for left paddle; guest sends right paddle.
  - Features:
      * Difficulty selection (Easy / Medium / Hard) for single-player (affects ball speed).
      * Incremental rendering to reduce flicker.
      * Fixed-timestep physics with interpolation for smooth motion.
      * Responsive immediate paddle movement with short release timeout.
      * Leaderboard with difficulty column and ANSI scroller output.
  - Cross-platform path handling: works on Windows and Linux.
*/

load("sbbsdefs.js");

try { require("dd_lightbar_menu.js", "DDLightbarMenu"); } catch(e) { /* optional */ }

var EventTimerAvailable = false;
try { load("event-timer.js"); EventTimerAvailable = true; } catch(e){ EventTimerAvailable = false; }

// ---------------- Config ----------------
var DEBUG = false;
var WIN_SCORE = 11;
var TICK_HZ = 60;
var FRAME_MS = Math.floor(1000 / TICK_HZ);
var PLAYER_INPUT_SAMPLES = 4;
var RELEASE_TIMEOUT_MS = 120; // ms
var PADDLE_MAX_BASE = 18;     // base max paddle speed (rows/sec)
var AI_BASE = 6;
var MULTI_WAIT_SECONDS = 180;

// global flags
var paused = false;
var quitRequested = false;

// ---------------- Cross-platform paths ----------------
var rawBase = (typeof js !== "undefined" && js.exec_dir) ? js.exec_dir : ".";
var SEP = (rawBase.indexOf("/") !== -1) ? "/" : "\\";
if (rawBase.slice(-1) !== SEP) rawBase += SEP;
var BASE_DIR = rawBase;

function pathJoin() {
  var parts = Array.prototype.slice.call(arguments).map(function(p){ return String(p); });
  var p = parts.join(SEP);
  // collapse repeated separators
  var re = new RegExp(SEP.replace(/\\/g,"\\\\") + "+", "g");
  p = p.replace(re, SEP);
  return p;
}

var SCORES_FILE = pathJoin(BASE_DIR, "pong_scores.json");
var MULTI_FILE  = pathJoin(BASE_DIR, "multimatch.json");
var ART_DIR     = pathJoin(BASE_DIR, "art");

// ensure base & art dirs exist
try {
  if (typeof file_exists === "function") {

    if (!file_exists(BASE_DIR)) {
      try { mkdir(BASE_DIR); } catch(e) {}
    }
    if (!file_exists(ART_DIR)) {
      try { mkdir(ART_DIR); } catch(e) {}
    }
  }
} catch(e){}

// ---------------- ANSI / Terminal ----------------
var ESC = "\x1b[";
var ANSI_RESET = ESC + "0m";
var ANSI_BOLD = ESC + "1m";
var ANSI_WHITE = ESC + "1;37m";
var ANSI_CYAN_BG = ESC + "46m";

var WIDTH = console.screen_columns || 80;
var HEIGHT = console.screen_rows || 24;

// ---------------- File helpers ----------------
function readJsonFile(fp){
  try{
    if(!file_exists(fp)) return null;
    var f=new File(fp);
    if(!f.open("r")) return null;
    var raw=f.readAll().join("");
    f.close();
    return JSON.parse(raw);
  }catch(e){ return null; }
}
function writeJsonFile(fp,obj){
  try{
    var f=new File(fp);
    if(!f.open("w")) {
      try{ console.print("Unable to open file for writing: " + fp + "\r\n"); } catch(e){}
      return false;
    }
    f.write(JSON.stringify(obj,null,2));
    f.close();
    return true;
  }catch(e){
    try{ console.print("Error writing JSON file: " + fp + " - " + (e && e.toString ? e.toString() : String(e)) + "\r\n"); } catch(x){}
    return false;
  }
}
function remove_file(fp){
  try{ var f=new File(fp); if(f.open("r")){ f.close(); f.remove(); return true; } }catch(e){} return false;
}

// ---------------- Leaderboard ----------------
function loadLeaderboard(){ var j = readJsonFile(SCORES_FILE); return (j && Array.isArray(j)) ? j : []; }
function saveLeaderboard(arr){ return writeJsonFile(SCORES_FILE, arr); }
function addScore(name,score,difficulty){ 
  try{ 
    var lb = loadLeaderboard(); 
    lb.push({
      name: name || "Guest",
      score: (typeof score === "number") ? score : (score ? Number(score) : 0),
      date: (new Date()).toISOString(),
      difficulty: difficulty || "Unknown"
    }); 
    lb.sort(function(a,b){return b.score-a.score}); 
    while(lb.length>200) lb.pop(); 
    saveLeaderboard(lb); 
    return true;
  }catch(e){ try{ console.print("Error saving score: " + e + "\r\n"); }catch(e2){} return false;} 
}

// ---------------- Terminal helpers ----------------
function hideCursor(){ try{ console.print("\x1b[?25l"); }catch(e){} }
function showCursor(){ try{ console.print("\x1b[?25h"); }catch(e){} }
function clearScreen(){ try{ console.clear(); }catch(e){} }
function centerText(s){ var pad = Math.max(0, Math.floor((WIDTH - s.length)/2)); return Array(pad+1).join(" ") + s; }

// title bar
function drawTitleBar(title){
  try{
    var full = Array(WIDTH+1).join(" ");
    console.gotoxy(1,1);
    console.print(ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + full + ANSI_RESET);
    var left = Math.floor((WIDTH - title.length)/2) + 1;
    if(left < 1) left = 1;
    if(left + title.length - 1 > WIDTH) left = Math.max(1, WIDTH - title.length + 1);
    console.gotoxy(left,1);
    console.print(ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + title + ANSI_RESET);
    console.gotoxy(1,2);
  }catch(e){}
}

function clearFooterLines(){ try{ console.gotoxy(1,HEIGHT-3); console.print(Array(WIDTH+1).join(" ")); console.gotoxy(1,HEIGHT-2); console.print(Array(WIDTH+1).join(" ")); console.gotoxy(1,HEIGHT-1); console.print(Array(WIDTH+1).join(" ")); console.gotoxy(1,HEIGHT); console.print(Array(WIDTH+1).join(" ")); }catch(e){} }
function setStatusLine(msg){ try{ console.gotoxy(1, HEIGHT-1); console.print(msg); console.cleartoeol(); }catch(e){} }

// ---------------- Input normalization ----------------
function readNormalizedKey(timeoutMillis){
  timeoutMillis = (typeof timeoutMillis === "number") ? timeoutMillis : 1;
  var k = console.inkey(K_NONE, timeoutMillis);
  if(!k) return null;
  try{
    if(typeof KEY_UP !== "undefined" && k === KEY_UP) return "UP";
    if(typeof KEY_DOWN !== "undefined" && k === KEY_DOWN) return "DOWN";
    if(typeof KEY_LEFT !== "undefined" && k === KEY_LEFT) return "LEFT";
    if(typeof KEY_RIGHT !== "undefined" && k === KEY_RIGHT) return "RIGHT";
  }catch(e){}
  var s = String(k);
  if(s === "\x1b"){
    var n1 = console.inkey(K_NONE,20);
    if(!n1) return "ESC";
    s += String(n1);
    var n2 = console.inkey(K_NONE,20);
    if(n2) s += String(n2);
    if(s === "\x1b[A" || s === "\x1bOA") return "UP";
    if(s === "\x1b[B" || s === "\x1bOB") return "DOWN";
    if(s === "\x1b[C" || s === "\x1bOC") return "RIGHT";
    if(s === "\x1b[D" || s === "\x1bOD") return "LEFT";
    if(s.indexOf("[A") !== -1) return "UP";
    if(s.indexOf("[B") !== -1) return "DOWN";
    if(s.indexOf("[C") !== -1) return "RIGHT";
    if(s.indexOf("[D") !== -1) return "LEFT";
    return null;
  }
  return s.toUpperCase();
}

// ---------------- AI scaling & helpers ----------------
function ai_max_speed_base(scoreL, scoreR, elapsedSeconds){
  var base = AI_BASE || 6;
  var timeFactor = Math.min(1.3, 1 + elapsedSeconds / 60.0);
  var scoreFactor = 1 + (Math.min(scoreL, Math.max(0, scoreR)) * 0.04);
  var speed = base * (1 + timeFactor * 0.5) * scoreFactor;
  return Math.min(40, Math.max(6, speed));
}

function computePaddleMax(ballVx, elapsedSeconds){
  var speedFromBall = Math.abs(ballVx) * 0.8;
  var timeFactor = Math.min(1.3, 1 + elapsedSeconds / 60.0);
  var max = (PADDLE_MAX_BASE || 18) + speedFromBall;
  max *= timeFactor;
  return Math.max(10, Math.min(80, Math.round(max)));
}

// ---------------- Render primitives ----------------
function clearFieldForOptions(opts){
  var fieldLeft = opts.fieldLeft, fieldTop = opts.fieldTop, fieldWidth = opts.fieldWidth, fieldHeight = opts.fieldHeight;
  var blankLine = Array(fieldWidth+1).join(" ");
  for(var r=0;r<fieldHeight;r++){ console.gotoxy(fieldLeft, fieldTop + r); console.print(blankLine); }
}
function drawHUDForOptions(scoreL, scoreR, opts, overrideInfo){
  var fieldLeft = opts.fieldLeft, fieldWidth = opts.fieldWidth, hudRow = opts.hudRow;
  var blueLine = ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + Array(fieldWidth+1).join(" ") + ANSI_RESET;
  console.gotoxy(fieldLeft, hudRow); console.print(blueLine);
  console.gotoxy(fieldLeft, hudRow+1); console.print(Array(fieldWidth+1).join(" "));
  var scoreText = " Score: " + scoreL + "   " + scoreR + " ";
  console.gotoxy(fieldLeft + 1, hudRow); console.print(ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + scoreText + ANSI_RESET);
  console.gotoxy(Math.floor((fieldWidth - 36)/2) + fieldLeft, hudRow);
  console.print(ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + "Controls: Up/Down arrows" + ANSI_RESET);
  var info = overrideInfo || "First to " + WIN_SCORE;
  var dbgStart = fieldLeft + fieldWidth - info.length - 1;
  if(dbgStart < fieldLeft + scoreText.length + 2) dbgStart = fieldLeft + scoreText.length + 2;
  console.gotoxy(dbgStart, hudRow); console.print(ANSI_BOLD + ANSI_CYAN_BG + ANSI_WHITE + info + ANSI_RESET);
  console.gotoxy(WIDTH, HEIGHT);
}

// incremental drawing helpers
function paddleCellsFor(paddle, fieldLeft, fieldTop, fieldHeight){
  var half = Math.floor(paddle.size/2);
  var yCenter = Math.round(paddle.y);
  var cells = [];
  for(var i = -half; i <= (paddle.size - half - 1); i++){
    var py = yCenter + i;
    if(py >= 1 && py <= fieldHeight){
      cells.push({ x: paddle.x, y: fieldTop + (py - 1) });
    }
  }
  return cells;
}
function eraseCells(cells){
  for(var i=0;i<cells.length;i++){
    try{ console.gotoxy(cells[i].x, cells[i].y); console.print(" "); }catch(e){}
  }
}
function drawPaddleCells(cells){
  for(var i=0;i<cells.length;i++){
    try{ console.gotoxy(cells[i].x, cells[i].y); console.print(ANSI_BOLD + ANSI_WHITE + "|" + ANSI_RESET); }catch(e){}
  }
}
function drawBallAbs(absX, absY){
  try{ console.gotoxy(absX, absY); console.print(ANSI_BOLD + ANSI_WHITE + "@" + ANSI_RESET); }catch(e){}
}
function eraseBallAbs(absX, absY){
  try{ console.gotoxy(absX, absY); console.print(" "); }catch(e){}
}

// ---------------- Multiplayer helpers ----------------
function createMatchFile(hostUser, hostAlias){ var m={hostUser:hostUser,hostAlias:hostAlias,guestUser:null,guestAlias:null,createdAt:(new Date()).toISOString(),lastHostPing:(new Date()).toISOString(),lastGuestPing:null,guestInput:{y:null,ts:null},state:null}; writeJsonFile(MULTI_FILE,m); return m; }
function readMatchFile(){ return readJsonFile(MULTI_FILE); }
function joinMatchFileAsGuest(userNumber, alias){ var m=readMatchFile(); if(!m) return {ok:false,error:"no match file"}; if(m.guestUser) return {ok:false,error:"match already has guest"}; m.guestUser=userNumber; m.guestAlias=alias||("User"+userNumber); m.lastGuestPing=(new Date()).toISOString(); writeJsonFile(MULTI_FILE,m); return {ok:true,match:m}; }

// ---------------- Utilities ----------------
function fmtPadRight(s,len){ s = String(s||""); while(s.length < len) s += " "; return s.substring(0,len); }
function sprintf(fmt){ var args=Array.prototype.slice.call(arguments,1); return fmt.replace(/%(-?\d*)([sd])/g,function(_,w,t){ var val=args.shift(); if(t==="s"){ w=parseInt(w,10)||0; var s=String(val||""); if(w<0){ while(s.length<Math.abs(w)) s+=" "; return s.substring(0,Math.abs(w)); } while(s.length<w) s=" "+s; return s; } else return String(val); }); }

// ---------------- Difficulty chooser ----------------
function chooseDifficulty(){
  var choices = [
    { id: "Easy", label: "Easy (standard)", mult: 1 },
    { id: "Medium", label: "Medium (ball speed x2)", mult: 2 },
    { id: "Hard", label: "Hard (ball speed x4)", mult: 4 }
  ];

  // compute dialog size and position
  var boxW = Math.min(56, WIDTH - 10);
  var boxH = choices.length + 4; // title + choices + padding
  var left = Math.floor((WIDTH - boxW) / 2) + 1;
  var top = Math.floor((HEIGHT - boxH) / 2) + 1;

  var borderColor = ANSI_BOLD + ESC + "36m"; // bright cyan fg
  var resetColor = ANSI_RESET;

  var sel = 0;
  var picked = null;

  try {
    hideCursor();

    // draw box
    try {
      console.gotoxy(left, top);
      console.print(borderColor + "+" + Array(boxW-1).join("-") + "+" + resetColor);
      for(var r=1;r<boxH-1;r++){
        console.gotoxy(left, top + r);
        console.print(borderColor + "|" + resetColor + Array(boxW-1).join(" ") + borderColor + "|" + resetColor);
      }
      console.gotoxy(left, top + boxH - 1);
      console.print(borderColor + "+" + Array(boxW-1).join("-") + "+" + resetColor);

      // title
      var title = "Select Difficulty";
      var titleLeft = left + Math.floor((boxW - title.length)/2);
      console.gotoxy(titleLeft, top + 1);
      console.print(ANSI_BOLD + title + ANSI_RESET);
    } catch(e) {
      try{ showCursor(); }catch(e){}
      return { id: "Easy", label: "Easy (standard)", mult: 1 };
    }

    // render loop
    while(true){
      for(var i=0;i<choices.length;i++){
        var lineY = top + 2 + i;
        console.gotoxy(left + 2, lineY);
        if(i === sel){
          console.print(ANSI_BOLD + ESC + "36m" + "> " + choices[i].label + ANSI_RESET + Array(Math.max(0, boxW - 6 - choices[i].label.length)).join(" "));
        } else {
          console.print("  " + choices[i].label + Array(Math.max(0, boxW - 6 - choices[i].label.length)).join(" "));
        }
      }

      var k = readNormalizedKey(0);
      if(!k){
        if(EventTimerAvailable) { try{ et_wait(1); } catch(e){ mswait(1); } } else mswait(1);
        continue;
      }

      if(k === "UP"){ sel = (sel - 1 + choices.length) % choices.length; continue; }
      if(k === "DOWN"){ sel = (sel + 1) % choices.length; continue; }
      if(k === "ESC" || k === "Q"){ picked = null; break; }
      if(k === "1" || k === "2" || k === "3"){
        var idx = parseInt(String(k),10) - 1;
        if(idx >= 0 && idx < choices.length){ picked = choices[idx]; break; }
      }
      var ks = String(k);
      if(ks === "\r" || ks === "\n" || ks === " "){ picked = choices[sel]; break; }
    }
  } finally {
    // erase box area and restore cursor
    try {
      for(var r2=0; r2<boxH; r2++){
        console.gotoxy(left, top + r2);
        console.print(Array(boxW+1).join(" "));
      }
    } catch(e){}
    try{ showCursor(); } catch(e){}
  }

  return picked;
}

// ---------------- ANSI scoreboard writer ----------------
function writeScoresAnsi(){
    try{
        var lb = loadLeaderboard();
        var lines = [];
        var now = new Date();
        lines.push("\x01h\x01b        A-NET PONG - LOCAL LEADERBOARD        \x01n");
        lines.push("");
        lines.push("\x01wLast Updated: " + now.toISOString().slice(0,10) + " " + now.toISOString().slice(11,19) + "\x01n");
        lines.push("");
        // Columns: Pos, Name(18), Score(7), Diff(8), Date(10)
        lines.push("\x01wPos  Name                 Score   Diff     Date\x01n");
        lines.push("");
        if(!lb || lb.length === 0){ lines.push("\x01wNo scores recorded yet.\x01n"); lines.push(""); } else {
            for(var i=0;i<Math.min(lb.length,200);i++){
                var e = lb[i];
                var pos = (i+1) + ".";
                var name = (e.name || "Guest").toString().substring(0,18);
                var diff = (e.difficulty || "N/A").toString().substring(0,8);
                var score = String(e.score || 0);
                var date = (e.date || "").slice(0,10);
                lines.push("\x01w" + fmtPadRight(pos,4) + " " + fmtPadRight(name,18) + " " + fmtPadRight(score,7) + " " + fmtPadRight(diff,8) + " " + date + "\x01n");
            }
        }
        lines.push("");
        lines.push("\x01cGenerated by A-NET PONG - " + (new Date()).toISOString() + "\x01n");
        lines.push("");
        var content = lines.join("\r\n");
        var path = pathJoin(ART_DIR, "pong-scores.ans");
        var f = new File(path);
        if(!f.open("w")) {
          try{ console.print("Unable to open " + path + " for writing. Check permissions.\r\n"); }catch(e){}
        } else {
          f.write(content); f.close();
        }
    }catch(e){ try{ console.print("Error generating ANSI scoreboard: " + (e && e.toString ? e.toString() : String(e)) + "\r\n"); }catch(e2){} }
}

// ---------------- High Scores screen (plain text) with difficulty column ----------------
function showHighScores(){
    try { if(typeof file_exists === "function" && !file_exists(ART_DIR)) mkdir(ART_DIR); } catch(e){}
    writeScoresAnsi();
    var scrollerPath = pathJoin(ART_DIR, "pong-scores.ans");
    if(file_exists(scrollerPath)){
        try { bbs.exec('?../xtrn/scroller/scroller.js "' + scrollerPath + '" "A-NET PONG - LOCAL LEADERBOARD" top'); return; }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + scrollerPath + '" "A-NET PONG - LOCAL LEADERBOARD" top'); return; }catch(e2){} }
    }
    clearScreen();
    drawTitleBar("PONG - High Scores");
    var lb = loadLeaderboard();
    if(!lb || lb.length === 0){
      console.gotoxy(3,4); console.print("No scores recorded yet.");
    } else {
      // Header with alignment: Rank, Score, Name, Diff, Date
      console.gotoxy(3,3);
      console.print(sprintf("%-4s %-6s %-18s %-8s %s", "Rank", "Score", "Name", "Diff", "Date"));
      for(var i=0;i<Math.min(lb.length,20);i++){
        var e=lb[i];
        var rank = (i+1) + ")";
        var score = String(e.score || 0);
        var name = (e.name || "Guest").toString().substring(0,18);
        var diff = (e.difficulty || "N/A").toString().substring(0,8);
        var date = (e.date || "").slice(0,10);
        console.gotoxy(3,5+i);
        console.print(sprintf("%-4s %-6s %-18s %-8s %s", rank, score, name, diff, date));
      }
    }
    console.gotoxy(1, HEIGHT); console.print("Press any key..."); console.getkey();
}

// ---------------- Game engine (single/local) with difficulty support ----------------
function playSingleOrLocalTwo(mode, difficultyObj){
  // mode: "single" or "two_local"
  // difficultyObj: { id, label, mult } or null (defaults to Easy)
  if(!difficultyObj) difficultyObj = { id: "Easy", label: "Easy (standard)", mult: 1 };

  paused = false; quitRequested = false;
  clearScreen(); drawTitleBar("PONG - " + (mode === "single" ? "Single Player ("+difficultyObj.id+")" : "Two Player (Local)"));
  var fieldTop = 3, fieldLeft = 1, fieldWidth = WIDTH, fieldHeight = HEIGHT - 6, hudRow = fieldTop + fieldHeight;

  var leftPaddle = { x:2, y: fieldHeight/2.0, prevY: fieldHeight/2.0, size:5, lastUp:0, lastDown:0, vy:0 };
  var rightPaddle = { x:fieldWidth-1, y: fieldHeight/2.0, prevY: fieldHeight/2.0, size:5, lastUp:0, lastDown:0, vy:0 };
  var ball = { prev:{x:fieldWidth/2.0, y:fieldHeight/2.0}, curr:{x:fieldWidth/2.0, y:fieldHeight/2.0}, vx:0, vy:0 };

  var scoreL = 0, scoreR = 0;
  var startTime = Date.now();

  // last-draw state
  var lastDraw = {
    ballAbs: { x: null, y: null },
    leftCells: [],
    rightCells: [],
    hudText: null
  };

  function resetBall(servingToLeft){
    var cx = fieldWidth/2.0, cy = fieldHeight/2.0;
    ball.prev.x = ball.curr.x = cx; ball.prev.y = ball.curr.y = cy;
    var maxAngle = Math.PI * 25/180;
    var ang = (Math.random() * (maxAngle*2)) - maxAngle;
    var dir = servingToLeft ? -1 : 1;
    var baseSpeed = 10 + Math.random()*4;
    var speed = baseSpeed * ((mode === "single") ? (difficultyObj.mult || 1) : 1);
    var vx = Math.cos(ang)*dir, vy = Math.sin(ang);
    var len = Math.sqrt(vx*vx + vy*vy) || 1;
    ball.vx = (vx/len)*speed; ball.vy = (vy/len)*speed;
  }

  function clampPaddle(p){ var half=Math.floor(p.size/2), minY=1+half, maxY=fieldHeight-half; if(p.y<minY)p.y=minY; if(p.y>maxY)p.y=maxY; }

  function physicsStep(dt){
    var now = Date.now();
    var elapsed = (now - startTime) / 1000.0;
    var maxSpeed = computePaddleMax(ball.vx, elapsed);

    var upAgeL = now - (leftPaddle.lastUp || 0);
    var downAgeL = now - (leftPaddle.lastDown || 0);
    if(upAgeL <= RELEASE_TIMEOUT_MS && downAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = 0;
    else if(upAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = -maxSpeed;
    else if(downAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = maxSpeed;
    else leftPaddle.vy = 0;

    if(mode === "two_local"){
      var upAgeR = now - (rightPaddle.lastUp || 0);
      var downAgeR = now - (rightPaddle.lastDown || 0);
      if(upAgeR <= RELEASE_TIMEOUT_MS && downAgeR <= RELEASE_TIMEOUT_MS) rightPaddle.vy = 0;
      else if(upAgeR <= RELEASE_TIMEOUT_MS) rightPaddle.vy = -maxSpeed;
      else if(downAgeR <= RELEASE_TIMEOUT_MS) rightPaddle.vy = maxSpeed;
      else rightPaddle.vy = 0;
    }

    leftPaddle.prevY = leftPaddle.y;
    rightPaddle.prevY = rightPaddle.y;

    leftPaddle.y += leftPaddle.vy * dt;
    if(mode === "two_local") rightPaddle.y += rightPaddle.vy * dt;

    clampPaddle(leftPaddle); clampPaddle(rightPaddle);

    ball.prev.x = ball.curr.x; ball.prev.y = ball.curr.y;
    ball.curr.x += ball.vx * dt; ball.curr.y += ball.vy * dt;

    if(ball.curr.y <= 1){ ball.curr.y = 1; ball.vy = Math.abs(ball.vy); }
    if(ball.curr.y >= fieldHeight){ ball.curr.y = fieldHeight; ball.vy = -Math.abs(ball.vy); }

    if(ball.vx < 0 && ball.curr.x <= leftPaddle.x + 0.9){
      var top = leftPaddle.y - Math.floor(leftPaddle.size/2), bot = leftPaddle.y + Math.floor((leftPaddle.size-1)/2);
      if(ball.curr.y >= top && ball.curr.y <= bot){
        ball.curr.x = leftPaddle.x + 1;
        ball.vx = Math.abs(ball.vx);
        var rel = (ball.curr.y - leftPaddle.y) / (leftPaddle.size/2); ball.vy += rel * 5;
        var speed = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy);
        speed = Math.max(5, speed * 1.02);
        var len = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy) || 1;
        ball.vx = (ball.vx / len) * speed; ball.vy = (ball.vy / len) * speed;
      }
    }
    if(ball.vx > 0 && ball.curr.x >= rightPaddle.x - 0.9){
      var top2 = rightPaddle.y - Math.floor(rightPaddle.size/2), bot2 = rightPaddle.y + Math.floor((rightPaddle.size-1)/2);
      if(ball.curr.y >= top2 && ball.curr.y <= bot2){
        ball.curr.x = rightPaddle.x - 1;
        ball.vx = -Math.abs(ball.vx);
        var rel2 = (ball.curr.y - rightPaddle.y) / (rightPaddle.size/2); ball.vy += rel2 * 5;
        var speed2 = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy);
        speed2 = Math.max(5, speed2 * 1.02);
        var len2 = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy) || 1;
        ball.vx = (ball.vx / len2) * speed2; ball.vy = (ball.vy / len2) * speed2;
      }
    }

    if(ball.curr.x < 0){ scoreR++; resetBall(true); drawHUDIfNeeded(); }
    else if(ball.curr.x > fieldWidth + 1){ scoreL++; resetBall(false); drawHUDIfNeeded(); }
  }

  function aiStep(dt){
    var elapsed = (Date.now() - startTime) / 1000.0;
    var max = ai_max_speed_base(scoreL, scoreR, elapsed);
    var diff = ball.curr.y - rightPaddle.y;
    var mv = Math.max(-max*dt, Math.min(max*dt, diff * 1.2));
    rightPaddle.y += mv;
    clampPaddle(rightPaddle);
  }

  var lastHudScores = { l: null, r: null };
  function drawHUDIfNeeded(){
    if(scoreL !== lastHudScores.l || scoreR !== lastHudScores.r){
      drawHUDForOptions(scoreL, scoreR, { fieldLeft: fieldLeft, fieldWidth: fieldWidth, hudRow: hudRow }, null);
      lastHudScores.l = scoreL; lastHudScores.r = scoreR;
    }
  }

  // incremental render
  function incrementalRender(alpha){
    var leftCells = paddleCellsFor(leftPaddle, fieldLeft, fieldTop, fieldHeight);
    var rightCells = paddleCellsFor(rightPaddle, fieldLeft, fieldTop, fieldHeight);
    var bx = ball.prev.x + (ball.curr.x - ball.prev.x) * alpha;
    var by = ball.prev.y + (ball.curr.y - ball.prev.y) * alpha;
    var absBX = fieldLeft + (Math.max(1, Math.min(fieldWidth, Math.round(bx))) - 1);
    var absBY = fieldTop + (Math.max(1, Math.min(fieldHeight, Math.round(by))) - 1);

    if(lastDraw.leftCells && lastDraw.leftCells.length) eraseCells(lastDraw.leftCells);
    if(lastDraw.rightCells && lastDraw.rightCells.length) eraseCells(lastDraw.rightCells);
    if(lastDraw.ballAbs.x !== null && lastDraw.ballAbs.y !== null) eraseBallAbs(lastDraw.ballAbs.x, lastDraw.ballAbs.y);

    drawPaddleCells(leftCells);
    drawPaddleCells(rightCells);
    drawBallAbs(absBX, absBY);

    lastDraw.leftCells = leftCells;
    lastDraw.rightCells = rightCells;
    lastDraw.ballAbs = { x: absBX, y: absBY };
  }

  // initial HUD draw
  drawHUDForOptions(scoreL, scoreR, { fieldLeft: fieldLeft, fieldWidth: fieldWidth, hudRow: hudRow }, null);
  lastHudScores.l = scoreL; lastHudScores.r = scoreR;

  resetBall(Math.random() < 0.5);

  var lastFrame = Date.now();
  var acc = 0;
  hideCursor();
  try {
    while(bbs.online && !js.terminated && !quitRequested){
      var now = Date.now();
      var dt = now - lastFrame; lastFrame = now;
      if(dt > 250) dt = 250;
      acc += dt;

      var steps = Math.floor(acc / FRAME_MS);
      if(steps > 6) steps = 6;
      for(var s=0;s<steps && !quitRequested;s++){
        for(var i=0;i<PLAYER_INPUT_SAMPLES;i++){
          var k = readNormalizedKey( (EventTimerAvailable) ? 1 : 0 );
          if(!k) continue;
          var ts = Date.now();
          if(k === "UP"){ leftPaddle.lastUp = ts; }
          else if(k === "DOWN"){ leftPaddle.lastDown = ts; }
          else if(mode === "two_local" && (k === "W" || k === "w")){ rightPaddle.lastUp = ts; }
          else if(mode === "two_local" && (k === "S" || k === "s")){ rightPaddle.lastDown = ts; }
          else if(k === "P"){ paused = !paused; if(paused){ console.gotoxy(1,hudRow+1); console.print("Paused - press P to resume"); } else { console.gotoxy(1,hudRow+1); console.print(Array(fieldWidth+1).join(" ")); } }
          else if(k === "Q" || k === "ESC"){ quitRequested = true; break; }
        }

        if(paused){
          var qk = readNormalizedKey(0);
          if(qk === "Q" || qk === "ESC") { quitRequested = true; break; }
        } else {
          if(mode === "single") aiStep(FRAME_MS/1000.0);
          physicsStep(FRAME_MS/1000.0);
        }
        acc -= FRAME_MS;
      }

      var alpha = acc / FRAME_MS;
      if(alpha < 0) alpha = 0; if(alpha > 1) alpha = 1;
      incrementalRender(alpha);

      if(EventTimerAvailable) { try{ et_wait(1); } catch(e){ mswait(1); } } else mswait(1);

      if(scoreL >= WIN_SCORE || scoreR >= WIN_SCORE) break;
    }
  } finally { showCursor(); }

  // cleanup last cells
  if(lastDraw.leftCells && lastDraw.leftCells.length) eraseCells(lastDraw.leftCells);
  if(lastDraw.rightCells && lastDraw.rightCells.length) eraseCells(lastDraw.rightCells);
  if(lastDraw.ballAbs.x !== null && lastDraw.ballAbs.y !== null) eraseBallAbs(lastDraw.ballAbs.x, lastDraw.ballAbs.y);

  // final HUD and end messages
  drawHUDForOptions(scoreL, scoreR, { fieldLeft: fieldLeft, fieldWidth: fieldWidth, hudRow: hudRow }, null);
  console.gotoxy(1,hudRow+1); console.print("Game Over. Final Score: " + scoreL + " - " + scoreR + "\r\n");
  var winner = scoreL > scoreR ? "Left Player" : (scoreR > scoreL ? "Right Player" : "Draw");
  console.print("Winner: " + winner + "\r\n");
  console.print("Save your score? (Y/N) ");
  var k2 = console.getkey();
  if(k2 && String(k2).toUpperCase() === "Y"){
    var defaultName = (typeof user !== "undefined" && user && user.alias) ? user.alias : "Player";
    console.gotoxy(1,hudRow+4); console.print("Enter name (blank to cancel) [" + defaultName + "]: ");
    var nm = console.getstr(defaultName, 20);
    if(nm && nm.trim().length) {
      // Save with difficulty label (for single-player) or "Local" for local two-player
      var difficultyLabel = (mode === "single" && difficultyObj && difficultyObj.id) ? difficultyObj.id : (mode === "two_local" ? "Local" : "Unknown");
      addScore(nm.trim().substring(0,20), Math.max(scoreL, scoreR), difficultyLabel);
      console.print("\r\nScore saved.");
    } else console.print("\r\nSave cancelled.");
    console.getkey();
  } else { console.print("\r\nNot saved."); console.getkey(); }
}

// ---------------- Multiplayer host/guest loops ----------------
function hostMultiplayerLoop(match, opts) {
  var fieldLeft = opts.fieldLeft, fieldTop = opts.fieldTop, fieldWidth = opts.fieldWidth, fieldHeight = opts.fieldHeight, hudRow = opts.hudRow;

  var leftPaddle = { x:2, y: fieldHeight/2.0, prevY: fieldHeight/2.0, size:5, lastUp:0, lastDown:0, vy:0 };
  var rightPaddle = { x:fieldWidth-1, y: fieldHeight/2.0, prevY: fieldHeight/2.0, size:5, lastUp:0, lastDown:0, vy:0 };
  var ball = { prev:{x:fieldWidth/2.0, y:fieldHeight/2.0}, curr:{x:fieldWidth/2.0, y:fieldHeight/2.0}, vx:0, vy:0 };
  var scoreL = 0, scoreR = 0;
  var startTime = Date.now();

  var lastDraw = { ballAbs: {x:null,y:null}, leftCells: [], rightCells: [], lastHud:{l:null,r:null} };

  function resetBall(servingToLeft){
    var cx = fieldWidth/2.0, cy = fieldHeight/2.0;
    ball.prev.x = ball.curr.x = cx; ball.prev.y = ball.curr.y = cy;
    var maxAngle = Math.PI * 25/180;
    var ang = (Math.random() * (maxAngle*2)) - maxAngle;
    var dir = servingToLeft ? -1 : 1;
    var speed = 10 + Math.random()*4;
    var vx = Math.cos(ang)*dir, vy = Math.sin(ang);
    var len = Math.sqrt(vx*vx + vy*vy) || 1;
    ball.vx = (vx/len)*speed; ball.vy = (vy/len)*speed;
  }

  function clampP(p){ var half=Math.floor(p.size/2), minY=1+half, maxY=fieldHeight-half; if(p.y<minY)p.y=minY; if(p.y>maxY)p.y=maxY; }

  function physicsStepHost(dt){
    var now = Date.now();
    var elapsed = (now - startTime) / 1000.0;
    var maxSpeed = computePaddleMax(ball.vx, elapsed);

    var upAgeL = now - (leftPaddle.lastUp || 0);
    var downAgeL = now - (leftPaddle.lastDown || 0);
    if(upAgeL <= RELEASE_TIMEOUT_MS && downAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = 0;
    else if(upAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = -maxSpeed;
    else if(downAgeL <= RELEASE_TIMEOUT_MS) leftPaddle.vy = maxSpeed;
    else leftPaddle.vy = 0;

    var m = readMatchFile();
    var guestY = (m && m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y : null;
    if(typeof guestY === "number") rightPaddle.y = guestY;

    leftPaddle.prevY = leftPaddle.y;
    rightPaddle.prevY = rightPaddle.y;

    leftPaddle.y += leftPaddle.vy * dt;

    clampP(leftPaddle); clampP(rightPaddle);

    ball.prev.x = ball.curr.x; ball.prev.y = ball.curr.y;
    ball.curr.x += ball.vx * dt; ball.curr.y += ball.vy * dt;

    if(ball.curr.y <= 1){ ball.curr.y = 1; ball.vy = Math.abs(ball.vy); }
    if(ball.curr.y >= fieldHeight){ ball.curr.y = fieldHeight; ball.vy = -Math.abs(ball.vy); }

    if(ball.vx < 0 && ball.curr.x <= leftPaddle.x + 0.9){
      var top = leftPaddle.y - Math.floor(leftPaddle.size/2), bot = leftPaddle.y + Math.floor((leftPaddle.size-1)/2);
      if(ball.curr.y >= top && ball.curr.y <= bot){
        ball.curr.x = leftPaddle.x + 1; ball.vx = Math.abs(ball.vx);
        var rel = (ball.curr.y - leftPaddle.y) / (leftPaddle.size/2); ball.vy += rel * 5;
        var speed = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy); speed = Math.max(5, speed * 1.02); var len = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy) || 1;
        ball.vx = (ball.vx / len) * speed; ball.vy = (ball.vy / len) * speed;
      }
    }
    if(ball.vx > 0 && ball.curr.x >= rightPaddle.x - 0.9){
      var top2 = rightPaddle.y - Math.floor(rightPaddle.size/2), bot2 = rightPaddle.y + Math.floor((rightPaddle.size-1)/2);
      if(ball.curr.y >= top2 && ball.curr.y <= bot2){
        ball.curr.x = rightPaddle.x - 1; ball.vx = -Math.abs(ball.vx);
        var rel2 = (ball.curr.y - rightPaddle.y) / (rightPaddle.size/2); ball.vy += rel2 * 5;
        var speed2 = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy); speed2 = Math.max(5, speed2 * 1.02); var len2 = Math.sqrt(ball.vx*ball.vx + ball.vy*ball.vy) || 1;
        ball.vx = (ball.vx / len2) * speed2; ball.vy = (ball.vy / len2) * speed2;
      }
    }

    if(ball.curr.x < 0){ scoreR++; resetBall(true); drawHUDHostIfNeeded(); }
    else if(ball.curr.x > fieldWidth + 1){ scoreL++; resetBall(false); drawHUDHostIfNeeded(); }
  }

  function drawHUDHostIfNeeded(){
    if(scoreL !== lastDraw.lastHud.l || scoreR !== lastDraw.lastHud.r){
      drawHUDForOptions(scoreL, scoreR, { fieldLeft: fieldLeft, fieldWidth: fieldWidth, hudRow: hudRow }, "HOST");
      lastDraw.lastHud.l = scoreL; lastDraw.lastHud.r = scoreR;
    }
  }

  function incrementalRenderHost(alpha){
    var leftCells = paddleCellsFor(leftPaddle, fieldLeft, fieldTop, fieldHeight);
    var rightCells = paddleCellsFor(rightPaddle, fieldLeft, fieldTop, fieldHeight);
    var bx = ball.prev.x + (ball.curr.x - ball.prev.x) * alpha;
    var by = ball.prev.y + (ball.curr.y - ball.prev.y) * alpha;
    var absBX = fieldLeft + (Math.max(1, Math.min(fieldWidth, Math.round(bx))) - 1);
    var absBY = fieldTop + (Math.max(1, Math.min(fieldHeight, Math.round(by))) - 1);

    if(lastDraw.leftCells && lastDraw.leftCells.length) eraseCells(lastDraw.leftCells);
    if(lastDraw.rightCells && lastDraw.rightCells.length) eraseCells(lastDraw.rightCells);
    if(lastDraw.ballAbs.x !== null && lastDraw.ballAbs.y !== null) eraseBallAbs(lastDraw.ballAbs.x, lastDraw.ballAbs.y);

    drawPaddleCells(leftCells);
    drawPaddleCells(rightCells);
    drawBallAbs(absBX, absBY);

    lastDraw.leftCells = leftCells;
    lastDraw.rightCells = rightCells;
    lastDraw.ballAbs = { x: absBX, y: absBY };
  }

  resetBall(Math.random() < 0.5);

  var last = Date.now();
  var acc = 0;
  hideCursor();
  try {
    while(bbs.online && !js.terminated && !quitRequested){
      var now = Date.now(); var delta = now - last; last = now;
      if(delta > 250) delta = 250; acc += delta;

      var steps = Math.floor(acc / FRAME_MS);
      if(steps > 6) steps = 6;
      for(var s=0;s<steps && !quitRequested;s++){
        for(var i=0;i<PLAYER_INPUT_SAMPLES;i++){
          var k = readNormalizedKey( (EventTimerAvailable) ? 1 : 0 );
          if(!k) break;
          var ts = Date.now();
          if(k === "UP") leftPaddle.lastUp = ts;
          else if(k === "DOWN") leftPaddle.lastDown = ts;
          else if(k === "P") paused = !paused;
          else if(k === "Q" || k === "ESC") { quitRequested = true; break; }
        }

        if(!paused) physicsStepHost(FRAME_MS/1000.0);
        acc -= FRAME_MS;
      }

      var mm = readMatchFile();
      if(mm){
        mm.state = { leftPaddle:{y:leftPaddle.y}, rightPaddle:{y:rightPaddle.y}, ball:{x:ball.curr.x,y:ball.curr.y,vx:ball.vx,vy:ball.vy}, scoreL:scoreL, scoreR:scoreR, running:true };
        mm.lastHostPing = (new Date()).toISOString();
        writeJsonFile(MULTI_FILE, mm);
      }

      drawHUDHostIfNeeded();

      var alpha = acc / FRAME_MS; if(alpha < 0) alpha = 0; if(alpha > 1) alpha = 1;
      incrementalRenderHost(alpha);

      if(EventTimerAvailable) { try{ et_wait(1); } catch(e){ mswait(1); } } else mswait(1);

      if(scoreL >= WIN_SCORE || scoreR >= WIN_SCORE) break;
    }
  } finally { showCursor(); }

  try{ remove_file(MULTI_FILE); } catch(e){}
  return { scoreL:scoreL, scoreR:scoreR };
}

function guestMultiplayerLoop(match, opts, userNumber){
  var fieldLeft = opts.fieldLeft, fieldTop = opts.fieldTop, fieldWidth = opts.fieldWidth, fieldHeight = opts.fieldHeight, hudRow = opts.hudRow;

  var lastDraw = { ballAbs:{x:null,y:null}, leftCells:[], rightCells:[], lastHud:{l:null,r:null} };

  hideCursor();
  try {
    while(bbs.online && !js.terminated && !quitRequested){
      var m = readMatchFile();
      if(!m){ setStatusLine("Host ended match"); mswait(600); break; }
      var kn = readNormalizedKey(1);
      var guestY = null;
      if(kn){
        if(kn === "UP") guestY = (m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y - 1 : Math.floor(fieldHeight/2) - 1;
        else if(kn === "DOWN") guestY = (m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y + 1 : Math.floor(fieldHeight/2) + 1;
        else if(kn === "W") guestY = (m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y - 1 : Math.floor(fieldHeight/2) - 1;
        else if(kn === "S") guestY = (m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y + 1 : Math.floor(fieldHeight/2) + 1;
        else if(kn === "Q" || kn === "ESC"){ quitRequested = true; setStatusLine("Leaving match..."); mswait(200); break; }
      }
      if(guestY === null) guestY = (m.guestInput && typeof m.guestInput.y === "number") ? m.guestInput.y : Math.floor(fieldHeight/2);
      guestY = Math.max(1, Math.min(fieldHeight, Math.round(guestY)));
      m.guestInput = { y:guestY, ts:(new Date()).toISOString() }; m.lastGuestPing = (new Date()).toISOString();
      writeJsonFile(MULTI_FILE, m);
      var state = m.state || null;
      if(state){
        var leftP = { x:2, y: state.leftPaddle.y, size:5 };
        var rightP = { x: fieldWidth-1, y: state.rightPaddle.y, size:5 };
        var leftCells = paddleCellsFor(leftP, fieldLeft, fieldTop, fieldHeight);
        var rightCells = paddleCellsFor(rightP, fieldLeft, fieldTop, fieldHeight);
        var absBX = fieldLeft + (Math.max(1, Math.min(fieldWidth, Math.round(state.ball.x))) - 1);
        var absBY = fieldTop + (Math.max(1, Math.min(fieldHeight, Math.round(state.ball.y))) - 1);

        if(lastDraw.leftCells && lastDraw.leftCells.length) eraseCells(lastDraw.leftCells);
        if(lastDraw.rightCells && lastDraw.rightCells.length) eraseCells(lastDraw.rightCells);
        if(lastDraw.ballAbs.x !== null && lastDraw.ballAbs.y !== null) eraseBallAbs(lastDraw.ballAbs.x, lastDraw.ballAbs.y);

        drawPaddleCells(leftCells);
        drawPaddleCells(rightCells);
        drawBallAbs(absBX, absBY);

        lastDraw.leftCells = leftCells;
        lastDraw.rightCells = rightCells;
        lastDraw.ballAbs = { x: absBX, y: absBY };

        if(state.scoreL !== lastDraw.lastHud.l || state.scoreR !== lastDraw.lastHud.r){
          drawHUDForOptions(state.scoreL, state.scoreR, { fieldLeft: fieldLeft, fieldWidth: fieldWidth, hudRow: hudRow }, "GUEST");
          lastDraw.lastHud.l = state.scoreL; lastDraw.lastHud.r = state.scoreR;
        }

        if(state.scoreL >= WIN_SCORE || state.scoreR >= WIN_SCORE) break;
      }
      mswait(1);
    }
  } finally { showCursor(); }
}

// ---------------- Instructions ----------------
function writeInstructionAnsi(topic, lines){
    try{
        var safe = String(topic || "instruction").toLowerCase().replace(/[^a-z0-9._-]+/g, '_').replace(/^_+|_+$/g,'');
        if(!safe) safe = "instruction";
        var filename = "pong-instr-" + safe + ".ans";
        var path = pathJoin(ART_DIR, filename);

        // ensure ART_DIR exists
        try { if(typeof file_exists === "function" && !file_exists(ART_DIR)) mkdir(ART_DIR); } catch(e){}

        var header = ANSI_BOLD + ANSI_WHITE + "        A-NET PONG - " + topic + "        " + ANSI_RESET + "\r\n\r\n";
        var content = header + lines.join("\r\n") + "\r\n";

        var f = new File(path);
        if(!f.open("w")){
          try{ console.print("Unable to open " + path + " for writing. Check permissions and path validity.\r\n"); }catch(e){}
          return null;
        }
        f.write(content);
        f.close();
        return path;
    }catch(e){
        try{ console.print("Error writing instruction ANSI (" + topic + "): " + (e && e.toString ? e.toString() : String(e)) + "\r\n"); }catch(e2){}
        return null;
    }
}

function showInstructions(){
    var topics = [
        { id:"controls", name:"Controls" },
        { id:"howto", name:"How to play" },
        { id:"multiplayer", name:"Multiplayer" }
    ];

    clearScreen();
    drawTitleBar("PONG - Instructions");
    var linesIntro = [
      "",
      "Instructions menu: Choose a topic using the menu below.",
      ""
    ];
    for(var i=0;i<linesIntro.length;i++) console.gotoxy(3,3+i), console.print(linesIntro[i]);

    console.gotoxy(3,7); console.print("1) Controls");
    console.gotoxy(3,8); console.print("2) How to play");
    console.gotoxy(3,9); console.print("3) Multiplayer notes");
    console.gotoxy(3,11); console.print("Choose topic [1-3] or press any other key to return: ");
    var c = console.getkey();
    if(!c) return;
    var choice = String(c);
    var t = null;
    if(choice === "1") t = topics[0];
    else if(choice === "2") t = topics[1];
    else if(choice === "3") t = topics[2];
    else return;

    var lines = [];
    if(t.id === "controls"){
        lines.push("Controls:");
        lines.push("");
        lines.push("Left paddle (player): Up/Down arrow keys");
        lines.push("Right paddle (local 2-player): W (up) / S (down)");
        lines.push("Pause: P");
        lines.push("Quit: Q or ESC");
    } else if(t.id === "howto"){
        lines.push("How to play:");
        lines.push("");
        lines.push("Single Player: Play against the AI (right paddle). First to " + WIN_SCORE + " wins.");
        lines.push("Two Player Local: Left uses Up/Down arrows, Right uses W/S.");
        lines.push("Multiplayer: Host creates a match file and waits for guest.");
    } else if(t.id === "multiplayer"){
        lines.push("Multiplayer notes:");
        lines.push("");
        lines.push("Host creates a match file and waits for a guest to join.");
        lines.push("Host runs the physics and writes state to the match JSON file.");
        lines.push("Guest sends paddle Y positions by updating the match file.");
        lines.push("Host can cancel by pressing Q/ESC.");
    }

    var path = writeInstructionAnsi(t.name, lines);
    if(path && file_exists(path)){
        try{ bbs.exec('?../xtrn/scroller/scroller.js "' + path + '" "A-NET PONG - ' + t.name + '" top'); return; }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + path + '" "A-NET PONG - ' + t.name + '" top'); return; }catch(e2){} }
    }

    console.clear();
    for(var li=0;li<lines.length;li++) console.print(lines[li] + "\r\n");
    console.print("\r\nPress any key to continue...\r\n");
    console.getkey();
}

// ---------------- Menu / entry ----------------
function playPong(mode, diffObj){
  // mode can be "single", "two_local", or "two" (network)
  if(mode === "single"){ playSingleOrLocalTwo("single", diffObj); return; }
  if(mode === "two_local"){ playSingleOrLocalTwo("two_local", null); return; }

  // networked multiplayer
  var me=(typeof user!=="undefined"&&user&&user.number)?user.number:9999;
  var alias=(typeof user!=="undefined"&&user&&user.alias)?user.alias:("User"+me);
  var existing=readMatchFile();
  if(!existing){
    createMatchFile(me,alias);
    clearScreen();
    drawTitleBar("PONG - Waiting for opponent (you are host)");
    console.gotoxy(3,4); console.print("Waiting for an opponent to join... (press Q/ESC to cancel)");
    var waited=0, joined=false;
    while(waited < MULTI_WAIT_SECONDS && bbs.online && !js.terminated){
      var k = readNormalizedKey(1000);
      if(k==="Q"||k==="ESC"){ remove_file(MULTI_FILE); console.gotoxy(3,6); console.print("Cancelled. Press any key..."); console.getkey(); return; }
      waited++;
      var m=readMatchFile();
      if(!m) break;
      if(m.guestUser){ joined=true; break; }
    }
    if(!joined){ remove_file(MULTI_FILE); console.gotoxy(3,6); console.print("No opponent joined. Press any key..."); console.getkey(); return; }
    var m2 = readMatchFile(); if(!m2){ console.print("Match disappeared."); return; }
    clearScreen();
    drawTitleBar("PONG - Host (multiplayer)");
    var opts={ fieldLeft:1, fieldTop:3, fieldWidth:WIDTH, fieldHeight:HEIGHT-6, hudRow:3+(HEIGHT-6) };
    var res = hostMultiplayerLoop(m2, opts);
    clearScreen();
    drawTitleBar("PONG - Match Ended");
    console.gotoxy(3,4); console.print("Final Score: " + res.scoreL + " - " + res.scoreR);
    console.gotoxy(3,6); console.print("Press any key..."); console.getkey();
    return;
  } else {
    if(existing.guestUser && existing.guestUser !== null){ clearScreen(); drawTitleBar("PONG - Join failed"); console.gotoxy(3,4); console.print("A match is already full. Press any key..."); console.getkey(); return; }
    if(existing.hostUser === me){ clearScreen(); drawTitleBar("PONG - Join failed"); console.gotoxy(3,4); console.print("You are already the host. Press any key..."); console.getkey(); return; }
    var j = joinMatchFileAsGuest(me, alias);
    if(!j.ok){ clearScreen(); drawTitleBar("PONG - Join failed"); console.gotoxy(3,4); console.print("Unable to join: "+(j.error||"unknown")+". Press any key..."); console.getkey(); return; }
    clearScreen(); drawTitleBar("PONG - Guest (multiplayer)");
    console.gotoxy(3,4); console.print("Joined match. Press Q/ESC to quit and return to menu.");
    var opts={ fieldLeft:1, fieldTop:3, fieldWidth:WIDTH, fieldHeight:HEIGHT-6, hudRow:3+(HEIGHT-6) };
    guestMultiplayerLoop(j.match, opts, me);
    clearScreen(); drawTitleBar("PONG - Match Ended (guest)");
    console.gotoxy(3,4); console.print("Match ended. Press any key..."); console.getkey();
    return;
  }
}

function mainMenu(){
  while(!js.terminated){
    clearScreen(); drawTitleBar("PONG - Main Menu");

    if(typeof DDLightbarMenu !== "undefined"){
      var lbMenu = new DDLightbarMenu(5, 3, WIDTH - 10, HEIGHT - 6);
      lbMenu.Add("Play Single Player", 1);
      lbMenu.Add("Play Two Player (Local)", 2);
      lbMenu.Add("Play Two Player (Network - Host/Join)", 3);
      lbMenu.Add("High Scores", 4);
      lbMenu.Add("Instructions", 5);
      lbMenu.Add("Quit", 6);

      lbMenu.colors.itemColor = "\x01k\x01h";
      lbMenu.colors.selectedItemColor = "\x01c\x01h"; // cyan
      lbMenu.colors.borderColor = "\x01c";
      lbMenu.AddAdditionalQuitKeys("qQ");
      lbMenu.borderEnabled = true;
      lbMenu.scrollbarEnabled = true;

      var val = lbMenu.GetVal();
      if(!val) return;
      var choice = parseInt(val,10);
      switch(choice){
        case 1:
          var diff = chooseDifficulty();
          if(diff) playPong("single", diff);
          break;
        case 2: playPong("two_local"); break;
        case 3: playPong("two"); break;
        case 4: showHighScores(); break;
        case 5: showInstructions(); break;
        case 6: return;
      }
    } else {
      var opts=["Play Single Player","Play Two Player (Local)","Play Two Player (Network - Host/Join)","High Scores","Instructions","Quit"];
      for(var i=0;i<opts.length;i++){ console.gotoxy(4,4+i); console.print((i+1)+") "+opts[i]); }
      clearFooterLines();
      console.gotoxy(1, HEIGHT-2); console.print("Choose an option [1-6]: ");
      var c = console.getkey();
      if(!c) continue;
      switch(c){
        case '1':
          var diff2 = chooseDifficulty();
          if(diff2) playPong("single", diff2);
          break;
        case '2': playPong("two_local"); break;
        case '3': playPong("two"); break;
        case '4': showHighScores(); break;
        case '5': showInstructions(); break;
        case '6': return;
        case 'q': case 'Q': return;
      }
    }
  }
}

// ---------------- Start ----------------
try {
  try { if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; } catch(e) {}
  mainMenu();
} catch (err) {
  try { console.print("\r\nFatal error: " + (err && err.toString ? err.toString() : String(err)) + "\r\n"); } catch(e) {}
}
