/*
  A-NET ARCADE (A-NetArcade.js) for Synchronet BBS 
  By: StingRay of A-Net Online BBS
  http://a-net.fyi - https://a-net-online.lol
  bbs.a-net.online - telnet: 1337 ssh:1338 rlogin:1339

  Edit games.json to add/edit/remove A-Net Arcade Games
  
  - Uses DDLightbarMenu
*/

load("sbbsdefs.js");

try { require("dd_lightbar_menu.js","DDLightbarMenu"); } catch(e){ /* optional */ }

try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}

/* Paths */
var rawBase = (typeof js !== "undefined" && js.exec_dir) ? js.exec_dir : ".";
var SEP = (rawBase.indexOf("/") !== -1) ? "/" : "\\";
if (rawBase.slice(-1) !== SEP) rawBase += SEP;
var BASE_DIR = rawBase;
var CONFIG_FILE = BASE_DIR + "games.json";

/* Defaults */
var DEFAULT_GAMES = [
  { id: "turtlebridge", title: "A-NET Turtle Bridge", file: "turtlebridge.js" },
  { id: "galaga",       title: "A-NET Galaga",       file: "galaga.js" },
  { id: "pong",         title: "A-NET Pong",         file: "pong.js" }
];

var ESC = "\x1b[";
var ANSI = {
  reset: ESC + "0m",
  bright: ESC + "1m",
  cyan: ESC + "1;36m",
  white: ESC + "1;37m"
};
var S = { reset:"\x01n", bright:"\x01h", black:"\x01k", cyan:"\x01c" };

/* Utilities */
function repeat(s,n){ var r=""; for(var i=0;i<n;i++) r+=s; return r; }
function existsPath(path){
  try{
    if(typeof file_exists === "function") return file_exists(path);
    var f=new File(path);
    if(f.open("r")){ f.close(); return true; }
    return false;
  }catch(e){ return false; }
}

function normalizePath(path){
  var p = path.replace(/\\/g, SEP).replace(/\//g, SEP);
  p = p.replace(new RegExp(SEP + "\\.(" + SEP + "|$)", "g"), SEP);
  var parts = p.split(SEP), out=[];
  for(var i=0;i<parts.length;i++){
    if(parts[i]===".."){
      if(out.length>0 && out[out.length-1] !== "..") out.pop(); else out.push("..");
    } else if(parts[i]==="") { if(i===0) out.push(""); } else out.push(parts[i]);
  }
  return out.join(SEP);
}

function readJsonFile(fp){
  try{
    if(typeof file_exists === "function" && !file_exists(fp)) return null;
    var f=new File(fp);
    if(!f.open("r")) return null;
    var raw = f.readAll().join("");
    f.close();
    return JSON.parse(raw);
  }catch(e){ return null; }
}

/* Load games.json (if valid), otherwise fallback to DEFAULT_GAMES */
function loadGamesFromConfig(){
  var j = readJsonFile(CONFIG_FILE);
  if(!j || !Array.isArray(j)) return DEFAULT_GAMES;
  var out = [];
  for(var i=0;i<j.length;i++){
    var it = j[i];
    if(!it || typeof it.file !== "string" || typeof it.title !== "string") continue;
    out.push({ id: it.id || ("g"+i), title: it.title, file: it.file, execOnly: !!it.execOnly });
  }
  return out.length ? out : DEFAULT_GAMES;
}

function launchGame(entry){
  var absLocal = normalizePath(BASE_DIR + entry.file);

  if(!entry.execOnly && existsPath(absLocal)){
    try{ load(absLocal); return true; }catch(e){ /* fall through */ }
  }

  var cand1 = normalizePath(BASE_DIR + ".." + SEP + "xtrn" + SEP + entry.file);
  if(existsPath(cand1)){
    try{ bbs.exec("?" + cand1); return true; }catch(e){}
  }

  var lower = BASE_DIR.toLowerCase();
  if(lower.indexOf(SEP + "exec" + SEP) !== -1){
    var repl = BASE_DIR.replace(new RegExp(SEP + "exec" + SEP + "?$", "i"), SEP + "xtrn" + SEP) + entry.file;
    repl = normalizePath(repl);
    if(existsPath(repl)){
      try{ bbs.exec("?" + repl); return true; }catch(e){}
    }
  }

  var sbbsIdx = lower.indexOf(SEP + "sbbs" + SEP);
  if(sbbsIdx !== -1){
    var prefix = BASE_DIR.substring(0, sbbsIdx + ("\\sbbs\\").length - 1);
    var candAbs = normalizePath(prefix + SEP + "xtrn" + SEP + entry.file);
    if(existsPath(candAbs)){
      try{ bbs.exec("?" + candAbs); return true; }catch(e){}
    }
  }

  // nothing found -> short notice
  try{ console.gotoxy(1, console.screen_rows || 24); console.print(S.bright + S.cyan + "Unable to launch " + entry.title + " (" + entry.file + ")." + S.reset); }catch(e){}
  return false;
}

/* Title bar */
function drawTitleBar(title){
  try{
    var cols = console.screen_columns || 80;
    console.clear();
    console.gotoxy(1,1);
    var full = repeat(" ", cols);
    console.print(ANSI.bright + ANSI.cyan + ANSI.white + full + ANSI.reset);
    var left = Math.floor((cols - title.length)/2) + 1;
    if(left < 1) left = 1;
    console.gotoxy(left,1);
    console.print(ANSI.bright + ANSI.cyan + ANSI.white + title + ANSI.reset);
    console.gotoxy(1,2);
  }catch(e){}
}

/* Clear & restore minimal terminal state after a game exits */
function clearAfterGame(){
  try{
    // small delay to allow external program to finish output
    mswait(50);
    // restore CP437 if possible
    try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}
    console.clear();
  }catch(e){}
}

/* Main menu */
function mainMenu(){
  while(!js.terminated){
    var games = loadGamesFromConfig();
    drawTitleBar("A-NET ARCADE");

    if(typeof DDLightbarMenu !== "undefined"){
      var cols = console.screen_columns || 80;
      var rows = console.screen_rows || 24;
      var menuW = Math.min(cols - 10, 64);
      var menuH = Math.min(rows - 6, 12);
      var menu = new DDLightbarMenu(5, 4, menuW, menuH);
      for(var i=0;i<games.length;i++) menu.Add(games[i].title, i+1);
      menu.Add("Quit", games.length+1);

      menu.colors.itemColor = "\x01k\x01h";
      menu.colors.selectedItemColor = "\x01c\x01h";
      menu.colors.borderColor = "\x01c";
      menu.AddAdditionalQuitKeys("qQ");
      menu.borderEnabled = true;
      menu.scrollbarEnabled = true;

      var v = menu.GetVal();
      if(!v) return;
      var choice = parseInt(v,10);
      if(isNaN(choice)) continue;
      if(choice === games.length+1) return;
      var entry = games[choice-1];

      launchGame(entry);

      // After a game returns, clear screen and redraw before continuing
      clearAfterGame();
      continue;
    }

    /* fallback text menu */
    var games = loadGamesFromConfig();
    for(var k=0;k<games.length;k++){
      console.gotoxy(4,4+k);
      console.print((k+1) + ") " + games[k].title);
    }
    console.gotoxy(4, 4 + games.length);
    console.print((games.length+1) + ") Quit");
    console.gotoxy(1, console.screen_rows || 24);
    console.print("Choose a game [1-" + (games.length+1) + "] or Q to quit: ");
    var c = console.getkey();
    if(!c) continue;
    var cs = String(c);
    if(cs.toUpperCase() === "Q") return;
    var n = parseInt(cs,10);
    if(isNaN(n) || n < 1 || n > (games.length+1)) continue;
    if(n === games.length+1) return;
    var sel = games[n-1];
    launchGame(sel);
    clearAfterGame();
    continue;
  }
}

/* Entrypoint */
try{ mainMenu(); }catch(err){ try{ console.print("\r\nFatal error in A-NET ARCADE: " + (err && err.toString ? err.toString() : String(err)) + "\r\n"); }catch(e){} }
