/*
  A-NET TURTLE BRIDGE (turtlebridge.js) - For Synchronet BBS v.02
  Author: StingRay of A-Net Online BBS - http://a-net.fyi - https://a-net-online.lol
*/

load("sbbsdefs.js");

try { require("dd_lightbar_menu.js", "DDLightbarMenu"); } catch(e) { /* optional */ }
var EventTimerAvailable = false;
try { load("event-timer.js"); EventTimerAvailable = true; } catch(e){ EventTimerAvailable = false; }

/* ---------------- Paths/Dirs (cross-platform) ---------------- */
var rawBase = (typeof js !== "undefined" && js.exec_dir) ? js.exec_dir : ".";
var SEP = (rawBase.indexOf("/") !== -1) ? "/" : "\\";
if (rawBase.slice(-1) !== SEP) rawBase += SEP;
var BASE_DIR = rawBase;
var DATA_DIR = BASE_DIR + "turtlebridge_data" + SEP;
var PLAYERS_DIR = DATA_DIR + "players" + SEP;
var LEADER_DIR = DATA_DIR + "leaderboards" + SEP;
var ART_DIR = BASE_DIR + "art" + SEP;
var SETTINGS_FILE = DATA_DIR + "settings.json";

function ensureDirs(){ var dirs=[DATA_DIR,PLAYERS_DIR,LEADER_DIR,ART_DIR]; for(var i=0;i<dirs.length;i++){ try{ if(typeof file_exists==="function" && !file_exists(dirs[i])) mkdir(dirs[i]); }catch(e){} } }
ensureDirs();

/* ---------------- Utilities ---------------- */
function readJsonFile(fp){ try{ if(typeof file_exists==="function" && !file_exists(fp)) return null; var f=new File(fp); if(!f.open("r")) return null; var raw=f.readAll().join(""); f.close(); return JSON.parse(raw);}catch(e){return null;} }
function writeJsonFile(fp,obj){ try{ var f=new File(fp); if(!f.open("w")) return false; f.write(JSON.stringify(obj,null,2)); f.close(); return true;}catch(e){return false;} }
function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }
function fmtPadRight(s,len){ s = String(s||""); while(s.length < len) s += " "; return s.substring(0,len); }
function repeatString(s,n){ var r=""; for(var i=0;i<n;i++) r+=s; return r; }
function hideCursor(){ try{ console.print("\x1b[?25l"); }catch(e){} }
function showCursor(){ try{ console.print("\x1b[?25h"); }catch(e){} }

/* ---------------- ANSI / Colors ---------------- */
var ESC = "\x1b[";
var ANSI_RESET = ESC + "0m";
var ANSI_BOLD  = ESC + "1m";
var C_RED   = ESC + "1;31m";
var C_GREEN = ESC + "1;32m";
var C_YELLOW= ESC + "1;33m";
var C_CYAN  = ESC + "1;36m";
var C_WHITE = ESC + "1;37m";
var C_BROWN = ESC + "0;33m";

/* ---------------- Settings ---------------- */
var DEFAULT_SETTINGS = { sound: true, difficulty: "Normal" };
function loadSettings(){ var s = readJsonFile(SETTINGS_FILE); if(!s) return DEFAULT_SETTINGS; return s; }
function saveSettings(s){ return writeJsonFile(SETTINGS_FILE, s); }
var Settings = loadSettings();

/* ---------------- Player ---------------- */
function playerFile(n){ return PLAYERS_DIR + "player-" + n + ".json"; }
function loadPlayer(n){ var j = readJsonFile(playerFile(n)); if(!j) return { userNumber:n, alias:(typeof user!=="undefined"&&user&&user.alias)?user.alias:"Guest", bestScore:0, totalPlays:0, lives:3, achievements:{} }; j.alias = j.alias || ((typeof user !== "undefined" && user && user.alias) ? user.alias : "Guest"); j.lives = (typeof j.lives === "number") ? j.lives : 3; j.achievements = j.achievements || {}; return j; }
function savePlayer(n,obj){ return writeJsonFile(playerFile(n), obj); }

/* ---------------- Leaderboard ---------------- */
var LB_FILE = LEADER_DIR + "turtlebridge-leaderboard.json";
function loadLeaderboard(){ var j = readJsonFile(LB_FILE); return (j && Array.isArray(j)) ? j : []; }
function saveLeaderboard(arr){ return writeJsonFile(LB_FILE, arr); }

/* ---------------- Game constants & tuning ---------------- */
var GAME_TICK_HZ = 12;                 // tick rate
var FRAME_MS = Math.floor(1000 / GAME_TICK_HZ);
var WIDTH = console.screen_columns || 80;
var HEIGHT = console.screen_rows || 24;

var INITIAL_LIVES = 3;
var MAX_LEVEL = 20;

/* Turtle timings tuned for calmer gameplay */
var TURTLE_COUNT = 5;
var PRE_DIVE_WARN_FRAMES = Math.max(2, Math.floor(GAME_TICK_HZ * 0.4));
var MIN_DIVE_SECONDS = 2;
var MAX_DIVE_SECONDS = 5;
var MIN_TIME_BEFORE_FIRST_DIVE_MS = 6000;  // longer safe period at start
var DIVE_SCHEDULE_COOLDOWN_MS = 1600;

/* Difficulty modifiers */
var DIFFICULTY = {
  "Easy":   { diveChance: 0.006, touristMinMs: 22000, touristMaxMs: 42000 },
  "Normal": { diveChance: 0.012, touristMinMs: 15000, touristMaxMs: 30000 },
  "Hard":   { diveChance: 0.024, touristMinMs: 10000, touristMaxMs: 20000 }
};

/* ---------------- Sounds (testing) ---------------- */
function playSound(type){
  if(!Settings.sound) return;
  try{
    switch(type){
      case "pickup": console.beep(1200,40); break;
      case "deliver": console.beep(1400,80); break;
      case "lost": console.beep(300,220); break;
      case "warn": console.beep(900,60); break;
      case "tick": console.beep(600,20); break;
    }
  }catch(e){}
}

/* ---------------- Scoreboard ANSI writer ---------------- */
function writeScoresAnsi(){
  try{
    var lb = loadLeaderboard();
    var lines = [];
    var now = new Date();
    lines.push(C_CYAN + ANSI_BOLD + "      A-NET TURTLE BRIDGE - LOCAL LEADERBOARD      " + ANSI_RESET);
    lines.push("");
    lines.push(C_WHITE + "Last Updated: " + now.toISOString().slice(0,10) + " " + now.toISOString().slice(11,19) + ANSI_RESET);
    lines.push("");
    lines.push(C_WHITE + fmtPadRight("Pos",4) + " " + fmtPadRight("Player",20) + " " + fmtPadRight("Score",6) + " " + fmtPadRight("Date",10) + ANSI_RESET);
    lines.push("");
    if(!lb || lb.length===0){ lines.push(C_WHITE + "No scores recorded yet." + ANSI_RESET); lines.push(""); }
    else {
      for(var i=0;i<Math.min(lb.length,200);i++){
        var e=lb[i], pos=(i+1)+".";
        lines.push(C_WHITE + fmtPadRight(pos,4) + " " + fmtPadRight((e.alias||"Guest").toString().substring(0,20),20) + " " + fmtPadRight(String(e.score||0),6) + " " + fmtPadRight((e.date||"").slice(0,10),10) + ANSI_RESET);
      }
    }
    lines.push(""); lines.push(C_CYAN + "Generated by A-NET TURTLE BRIDGE - " + (new Date()).toISOString() + ANSI_RESET);
    lines.push("");
    var content = lines.join("\r\n");
    var path = ART_DIR + "turtlebridge-scores.ans";
    var f = new File(path);
    if(f.open("w")){ f.write(content); f.close(); }
  }catch(e){}
}

/* ---------------- Input normalization ---------------- */
function readNormalizedKey(timeoutMillis){
  timeoutMillis = (typeof timeoutMillis === "number") ? timeoutMillis : 1;
  var k = console.inkey(K_NONE, timeoutMillis);
  if(!k) return null;
  try{
    if(typeof KEY_LEFT !== "undefined" && k === KEY_LEFT) return "LEFT";
    if(typeof KEY_RIGHT !== "undefined" && k === KEY_RIGHT) return "RIGHT";
  }catch(e){}
  var s = String(k);
  if(s === "\x1b"){
    var n1 = console.inkey(K_NONE,20); if(!n1) return "ESC"; s += String(n1);
    var n2 = console.inkey(K_NONE,20); if(n2) s += String(n2);
    if(s === "\x1b[D" || s === "\x1bOD") return "LEFT";
    if(s === "\x1b[C" || s === "\x1bOC") return "RIGHT";
    return null;
  }
  return s.toUpperCase();
}

/* ---------------- Gameplay helpers ---------------- */
function defaultTurtleObj(){
  var cycle = 90 + Math.floor(Math.random()*30);
  var visibleFrames = Math.max(6, Math.floor(cycle * 0.75));
  return { submerged:false, warn:false, diveStartMs:0, diveEndMs:0, nextAvailableMs:0, cycle:cycle, visibleFrames:visibleFrames };
}

/* ---------------- Instructions ---------------- */
function showInstructions(){
  var lines = [
    "Turtle Bridge - Instructions",
    "",
    "Objective: Move luggage from left bank to the tourist on the right bank by",
    "jumping across five turtles. Turtles dive periodically;",
    "Don't stand on diving turtles.",
    "",
    "Controls:",
    "  LEFT/RIGHT arrows (or A/D) to hop between turtles and banks.",
    "  P to pause, Q or ESC to quit.",
    "",
    "Scoring:",
    " +3 points per successful delivery.",
    " +2..+12 bonus points based on speed between deliveries (faster = bigger bonus)",
    "",
    "You have three lives. Lose a life by falling into the water,",
    "stepping on a diving turtle, or if the tourist disappears while",
    "  you're carrying luggage.",
    "",
    "Press any key to return..."
  ];
  console.clear();
  for(var i=0;i<lines.length;i++) console.print(lines[i] + "\r\n");
  console.getkey();
}

/* ---------------- Main game function ---------------- */
function startTurtleBridge(userNumber){
  ensureDirs();
  try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}
  var pdata = loadPlayer(userNumber);
  pdata.alias = pdata.alias || ((typeof user !== "undefined" && user && user.alias) ? user.alias : "Guest");
  pdata.lives = (typeof pdata.lives === "number") ? pdata.lives : INITIAL_LIVES;
  pdata.score = pdata.score || 0;

  // Field geometry
  var fieldWidth = Math.min(60, Math.max(40, Math.floor(WIDTH * 0.6)));
  var fieldLeft = Math.floor((WIDTH - fieldWidth) / 2) + 1;
  var bridgeY    = Math.floor(HEIGHT / 2);
  var leftBankX  = fieldLeft - 6;
  var rightBankX = fieldLeft + fieldWidth + 5;

  var spriteW = 3;
  var turtlePositions = [];
  for(var i=0;i<TURTLE_COUNT;i++){
    var slotWidth = Math.floor((fieldWidth - spriteW) / TURTLE_COUNT);
    var ax = fieldLeft + i*slotWidth + Math.floor((slotWidth - spriteW)/2);
    if(ax < fieldLeft) ax = fieldLeft;
    if(ax + spriteW - 1 > fieldLeft + fieldWidth - 1) ax = fieldLeft + fieldWidth - spriteW;
    turtlePositions.push(ax);
  }

  var level = 1, deliveries = 0, running = true;
  var playerPos = -1;

  // start carrying luggage
  var carrying = true;
  var lastDeliveryTime = null;

  // tourist scheduling (ms)
  var touristPresent = true;
  var touristWillLeave = false;
  var touristLeaveAt = 0;
  var now = Date.now();
  var difficulty = Settings.difficulty || "Normal";
  var diffCfg = DIFFICULTY[difficulty] || DIFFICULTY["Normal"];
  var touristNextEventMs = now + (diffCfg.touristMinMs + Math.floor(Math.random()*(diffCfg.touristMaxMs - diffCfg.touristMinMs + 1)));

  // luggage flow
  var luggageAvailable = false;
  var waitingForReturn = false;

  // safe start
  var startedAt = Date.now();
  var safeStartMs = startedAt + 2000; // 2s protection

  // ticks/timekeeping
  var ticks = 0;
  var lastDiveMs = 0;

  // turtles init
  var turtles = [];
  for(var t=0;t<TURTLE_COUNT;t++) turtles.push(defaultTurtleObj());

  // lastMap for diff rendering
  var lastMap = {};

  // HUD placement
  var HUD_LINE1 = Math.max(HEIGHT - 2, bridgeY + 4);
  var HUD_LINE2 = Math.max(HEIGHT - 1, HUD_LINE1 + 1);

  function drawStaticScene(){
    console.clear();
    console.gotoxy(1,1);
    var title = "A-NET TURTLE BRIDGE";
    var pad = Math.max(0, Math.floor((WIDTH - title.length) / 2));
    console.print(ANSI_BOLD + C_CYAN + repeatString(" ", pad) + title + repeatString(" ", pad) + ANSI_RESET + "\r\n\r\n");

    for(var y=bridgeY-2;y<=bridgeY+2;y++){
      console.gotoxy(leftBankX - 2, y); console.print(C_BROWN + "|||||" + ANSI_RESET);
      console.gotoxy(rightBankX, y);    console.print(C_BROWN + "|||||" + ANSI_RESET);
    }
    console.gotoxy(leftBankX - 5, bridgeY - 1);  console.print(C_WHITE + "Left Bank" + ANSI_RESET);
    console.gotoxy(rightBankX - 1, bridgeY - 1); console.print(C_WHITE + "Tourist" + ANSI_RESET);

    var waterLine = C_CYAN + repeatString("~", fieldWidth) + ANSI_RESET;
    console.gotoxy(fieldLeft, bridgeY + 1);
    console.print(waterLine);

    drawHud(true);
    lastMap = {};
  }

  function drawHud(force){
    force = !!force;
    // Line 1: Lives, Score, Deliveries, Level
    try{
      console.gotoxy(1, HUD_LINE1);
      var livesStr = "Lives: " + pdata.lives;
      var scoreStr = "Score: " + pdata.score;
      var delStr   = "Deliveries: " + deliveries;
      var lvlStr   = "Level: " + level;
      var leftPart = fmtPadRight(livesStr,14) + fmtPadRight(scoreStr,18) + fmtPadRight(delStr,20) + fmtPadRight(lvlStr,12);
      var line1 = (leftPart + repeatString(" ", Math.max(0, WIDTH - leftPart.length))).substring(0,WIDTH);
      console.print(ANSI_BOLD + C_WHITE + line1 + ANSI_RESET);
    }catch(e){}

    // Line 2: Carrying, Difficulty, Sound
    try{
      console.gotoxy(1, HUD_LINE2);
      var carryStr = "Carrying: " + (carrying ? "YES" : "NO");
      var diffStr  = "Diff: " + (Settings.difficulty || "Normal");
      var soundStr = "Sound: " + (Settings.sound ? "ON" : "OFF");
      var rightPart = fmtPadRight(carryStr,14) + fmtPadRight(diffStr,20);
      var remaining = WIDTH - rightPart.length - soundStr.length - 1;
      if(remaining < 0) remaining = 0;
      var line2 = rightPart + repeatString(" ", remaining) + soundStr;
      line2 = (line2 + repeatString(" ", Math.max(0, WIDTH - line2.length))).substring(0, WIDTH);
      console.print(ANSI_BOLD + C_WHITE + line2 + ANSI_RESET);
    }catch(e){}
  }

  // Build current dynamic map
  function buildMap(){
    var map = {};

    // turtles: draw ".t." at ax, ax+1, ax+2
    for(var i=0;i<TURTLE_COUNT;i++){
      var t = turtles[i];
      var ax = turtlePositions[i];
      var ay = bridgeY;
      if(t.submerged) continue;
      var color = t.warn ? C_YELLOW : C_GREEN;
      map[ax + "," + ay]     = { ch: ".", color: color, tag: "turtle" + i + "-0" };
      map[(ax+1) + "," + ay] = { ch: "t", color: color, tag: "turtle" + i + "-1" };
      map[(ax+2) + "," + ay] = { ch: ".", color: color, tag: "turtle" + i + "-2" };
    }

    // player: place at center column of turtle sprite when on a turtle
    var px, py = bridgeY;
    if(playerPos === -1) px = leftBankX - 1;
    else if(playerPos === TURTLE_COUNT) px = rightBankX + 1;
    else {
      var ax = turtlePositions[playerPos];
      px = ax + Math.floor(spriteW/2); // center column
    }
    var pch = carrying ? "@" : "P";
    map[px + "," + py] = { ch: pch, color: C_WHITE, tag: "player" };

    // luggage on left bank if present
    if(luggageAvailable) map[(leftBankX - 1) + "," + (bridgeY - 1)] = { ch: "L", color: C_WHITE, tag: "luggage" };

    // tourist: flash when will leave soon
    if(touristPresent){
      var tcolor = touristWillLeave ? C_YELLOW : C_WHITE;
      map[(rightBankX + 1) + "," + (bridgeY - 1)] = { ch: "T", color: tcolor, tag: "tourist" };
    }

    return map;
  }

  // Diff renderer writes only changed cells
  function renderDiff(curMap){
    var union = {};
    for(var k in lastMap) union[k]=true;
    for(var k2 in curMap) union[k2]=true;
    for(var key in union){
      var last = lastMap[key];
      var cur  = curMap[key];
      if(!last && cur){
        var p = key.split(","); var ax=parseInt(p[0],10), ay=parseInt(p[1],10);
        try{ console.gotoxy(ax, ay); console.print((cur.color?cur.color:"") + cur.ch + ANSI_RESET); }catch(e){}
      } else if(last && !cur){
        var p2 = key.split(","); var ax2=parseInt(p2[0],10), ay2=parseInt(p2[1],10);
        try{
          console.gotoxy(ax2, ay2);
          if(ay2 === bridgeY + 1) console.print(C_CYAN + "~" + ANSI_RESET);
          else console.print(" ");
        }catch(e){}
      } else if(last && cur){
        if(last.ch !== cur.ch || last.color !== cur.color){
          var p3 = key.split(","); var ax3=parseInt(p3[0],10), ay3=parseInt(p3[1],10);
          try{ console.gotoxy(ax3, ay3); console.print((cur.color?cur.color:"") + cur.ch + ANSI_RESET); }catch(e){}
        }
      }
    }
    lastMap = curMap;
  }

  // Dive scheduler — uses difficulty diveChance and ensures one-at-a-time dives
  function maybeScheduleDive(nowMs){
    var chancePerTick = DIFFICULTY[Settings.difficulty || "Normal"].diveChance || DIFFICULTY["Normal"].diveChance;
    if(nowMs - startedAt < MIN_TIME_BEFORE_FIRST_DIVE_MS) return;
    if(nowMs - lastDiveMs < DIVE_SCHEDULE_COOLDOWN_MS) return;
    for(var ti=0; ti<TURTLE_COUNT; ti++){
      if(turtles[ti].submerged) return;
      if(turtles[ti].diveStartMs && turtles[ti].diveStartMs > nowMs && (turtles[ti].diveStartMs - nowMs) < 2000) return;
    }
    if(Math.random() < chancePerTick){
      var candidates = [];
      for(var ti2=0; ti2<TURTLE_COUNT; ti2++){
        var tt = turtles[ti2];
        if(!tt.submerged && (!tt.diveStartMs || tt.diveStartMs <= nowMs)) candidates.push(ti2);
      }
      if(candidates.length === 0) return;
      var pick = candidates[Math.floor(Math.random()*candidates.length)];
      var delayUntilWarnMs = 500 + Math.floor(Math.random()*900);
      var warnDelayMs = (PRE_DIVE_WARN_FRAMES * FRAME_MS);
      var diveDurationMs = (MIN_DIVE_SECONDS*1000) + Math.floor(Math.random()*((MAX_DIVE_SECONDS-MIN_DIVE_SECONDS+1)*1000));
      var diveStartMs = nowMs + delayUntilWarnMs + warnDelayMs;
      var diveEndMs = diveStartMs + diveDurationMs;
      turtles[pick].diveStartMs = diveStartMs;
      turtles[pick].diveEndMs = diveEndMs;
      turtles[pick].nextAvailableMs = diveEndMs + 800 + Math.floor(Math.random()*800);
      lastDiveMs = nowMs;
    }
  }

  // Update logic: turtles phases and tourist scheduling
  function updateLogic(){
    ticks++;
    var nowMs = Date.now();
    maybeScheduleDive(nowMs);

    for(var ti=0; ti<TURTLE_COUNT; ti++){
      var t = turtles[ti];
      t.warn = false;
      if(t.diveStartMs && nowMs >= t.diveStartMs && nowMs < t.diveEndMs){
        t.submerged = true;
      } else if(t.diveEndMs && nowMs >= t.diveEndMs){
        t.submerged = false;
        t.diveStartMs = 0;
        t.diveEndMs = 0;
      } else if(t.diveStartMs && nowMs < t.diveStartMs){
        var warnWindowStartMs = t.diveStartMs - (PRE_DIVE_WARN_FRAMES * FRAME_MS);
        if(nowMs >= warnWindowStartMs) {
          if(!t.warn) playSound("warn");
          t.warn = true;
        }
      } else {
        t.submerged = false;
      }
    }

    // tourist: use larger time windows from difficulty
    var now = Date.now();
    var cfg = DIFFICULTY[Settings.difficulty || "Normal"];
    if(touristPresent){
      if(!touristWillLeave && now >= touristNextEventMs && now >= safeStartMs){
        touristWillLeave = true;
        touristLeaveAt = now + 3000; // 3s warning
        touristNextEventMs = touristLeaveAt;
      } else if(touristWillLeave && now >= touristLeaveAt){
        touristPresent = false;
        touristWillLeave = false;
        touristNextEventMs = now + (cfg.touristMinMs + Math.floor(Math.random()*(cfg.touristMaxMs - cfg.touristMinMs + 1)));
        if(carrying) loseLife("Tourist left while carrying luggage!");
      }
    } else {
      if(now >= touristNextEventMs){
        touristPresent = true;
        touristWillLeave = false;
        touristNextEventMs = now + (cfg.touristMinMs + Math.floor(Math.random()*(cfg.touristMaxMs - cfg.touristMinMs + 1)));
      }
    }
  }

  function autoPickupIfReturned(){
    if(playerPos === -1 && !carrying && (waitingForReturn || luggageAvailable)){
      carrying = true;
      waitingForReturn = false;
      luggageAvailable = false;
      playSound("pickup");
      drawHud(true);
    }
  }

  // Lose life (respect safe-start)
  function loseLife(reason){
    if(Date.now() < safeStartMs){
      playerPos = -1;
      carrying = false;
      luggageAvailable = true;
      waitingForReturn = false;
      drawHud(true);
      return;
    }
    pdata.lives--;
    waitingForReturn = false;
    luggageAvailable = true;
    carrying = false;
    playSound("lost");
    drawHud(true);
    console.gotoxy(1, bridgeY + 6);
    console.print(C_RED + "Lost a life: " + (reason || "") + ANSI_RESET);
    mswait(700);
    console.gotoxy(1, bridgeY + 6); console.print(repeatString(" ", WIDTH));
    playerPos = -1;
    if(pdata.lives <= 0) running = false;
  }

  // Pickup/deliver logic
  function tryPickup(){
    if(playerPos === -1 && luggageAvailable && !carrying){
      carrying = true;
      luggageAvailable = false;
      playSound("pickup");
    }
  }
  function tryDeliver(){
    if(playerPos === TURTLE_COUNT){
      if(!carrying) return;
      if(!touristPresent){
        loseLife("Tourist absent at delivery");
        return;
      }
      pdata.score = (pdata.score || 0) + 3;
      deliveries++;
      var bonus = 0;
      var now = Date.now();
      if(lastDeliveryTime){
        var sec = Math.max(0, (now - lastDeliveryTime)/1000.0);
        var capped = Math.min(15, sec);
        var ratio = 1 - (capped / 15.0);
        bonus = 2 + Math.round(ratio * 10);
      }
      pdata.score += bonus;
      lastDeliveryTime = now;
      carrying = false;
      waitingForReturn = true;
      playSound("deliver");
      if(deliveries % 3 === 0) level = Math.min(MAX_LEVEL, level + 1);
      drawHud(true);
    }
  }

  // Player movement
  function movePlayerLeft(){
    if(playerPos === -1) return;
    if(playerPos === 0){
      playerPos = -1;
      if(waitingForReturn && !carrying){
        carrying = true;
        waitingForReturn = false;
        playSound("pickup");
        drawHud(true);
      } else tryPickup();
      return;
    }
    if(playerPos === TURTLE_COUNT){ playerPos = TURTLE_COUNT - 1; return; }
    playerPos = Math.max(-1, playerPos - 1);
    if(playerPos >= 0 && playerPos < TURTLE_COUNT){
      var t = turtles[playerPos];
      if(t.submerged) loseLife("Stepped on diving turtle");
    }
    if(playerPos === -1){
      if(waitingForReturn && !carrying){
        carrying = true;
        waitingForReturn = false;
        playSound("pickup");
        drawHud(true);
      } else tryPickup();
    }
  }

  function movePlayerRight(){
    if(playerPos === TURTLE_COUNT) return;
    if(playerPos === -1){ playerPos = 0; if(turtles[0].submerged) loseLife("Stepped on diving turtle"); return; }
    playerPos = Math.min(TURTLE_COUNT, playerPos + 1);
    if(playerPos >= 0 && playerPos < TURTLE_COUNT){
      var t = turtles[playerPos];
      if(t.submerged) loseLife("Stepped on diving turtle");
    } else if(playerPos === TURTLE_COUNT){
      tryDeliver();
    }
  }

  // initial draw & loop
  drawStaticScene();
  hideCursor();

  var lastFrame = Date.now();
  try{
    while(bbs.online && !js.terminated && running){
      var now = Date.now();
      var dtMs = now - lastFrame; if(dtMs > 700) dtMs = 700;
      lastFrame = now;
      var frames = Math.max(1, Math.floor(dtMs / FRAME_MS));
      for(var f=0; f<frames; f++){
        var k = readNormalizedKey(0);
        if(k){
          if(k === "LEFT" || k === "A") movePlayerLeft();
          else if(k === "RIGHT" || k === "D") movePlayerRight();
          else if(k === "P"){ console.gotoxy(1, bridgeY + 6); console.print("Paused - press any key to resume..."); console.getkey(); drawStaticScene(); }
          else if(k === "Q" || k === "ESC"){ running = false; break; }
        }

        updateLogic();

        // ensure auto pickup if player landed/returned to left bank at any time
        autoPickupIfReturned();

        // if on turtle that submerged
        if(playerPos >= 0 && playerPos < TURTLE_COUNT){
          if(turtles[playerPos].submerged) loseLife("Turtle dove under you");
        }
      }
      var curMap = buildMap();
      renderDiff(curMap);
      if(EventTimerAvailable) { try{ et_wait(1); } catch(e){ mswait(1); } } else mswait(1);
    }
  } finally {
    showCursor();
  }

  // Save player & leaderboard
  pdata.totalPlays = (pdata.totalPlays || 0) + 1;
  if((pdata.score || 0) > (pdata.bestScore || 0)) pdata.bestScore = pdata.score;
  pdata.lives = pdata.lives || 0;
  savePlayer(userNumber, pdata);

  try{
    var lb = loadLeaderboard();
    lb.push({ alias: pdata.alias, score: pdata.score || 0, date: (new Date()).toISOString() });
    lb.sort(function(a,b){ return b.score - a.score; });
    while(lb.length > 200) lb.pop();
    saveLeaderboard(lb);
    writeScoresAnsi();
  }catch(e){}

  // End screen
  console.clear();
  console.print(ANSI_BOLD + C_CYAN + "===== TURTLE BRIDGE - GAME OVER =====" + ANSI_RESET + "\r\n");
  console.print("Player: " + pdata.alias + "\r\n");
  console.print("Score: " + (pdata.score || 0) + "\r\n");
  console.print("Deliveries: " + deliveries + "\r\n\r\n");
  console.print("View full scoreboard? (Y/N) ");
  var kk = console.getkey();
  if(kk && String(kk).toUpperCase() === "Y"){
    var scrollerPath = ART_DIR + "turtlebridge-scores.ans";
    writeScoresAnsi();
    try{ bbs.exec('?../xtrn/scroller/scroller.js "' + scrollerPath + '" "A-NET TURTLE BRIDGE - LOCAL LEADERBOARD" top'); }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + scrollerPath + '" "A-NET TURTLE BRIDGE - LOCAL LEADERBOARD" top'); }catch(e2){} }
  }

}

/* ---------------- Menu / Settings ---------------- */
function showSettingsMenu(){
  while(true){
    console.clear();
    console.gotoxy(2,3);
    console.print("Settings:\r\n\r\n");
    console.print("1) Sound: " + (Settings.sound ? "ON" : "OFF") + "\r\n");
    console.print("2) Difficulty: " + (Settings.difficulty || "Normal") + "\r\n");
    console.print("3) Back\r\n\r\n");
    console.print("Choose [1-3]: ");
    var k = console.getkey();
    if(!k) continue;
    if(k === "1"){
      Settings.sound = !Settings.sound;
      saveSettings(Settings);
    } else if(k === "2"){
      var choices = ["Easy","Normal","Hard"];
      if(typeof DDLightbarMenu !== "undefined"){
        var m = new DDLightbarMenu(10,6,30,8);
        for(var i=0;i<choices.length;i++) m.Add(choices[i], i+1);
        m.AddAdditionalQuitKeys("qQ");
        var v = m.GetVal();
        if(v) Settings.difficulty = choices[parseInt(v,10)-1];
      } else {
        console.print("Select Difficulty [1]Easy [2]Normal [3]Hard: ");
        var c = console.getkey();
        if(c && "123".indexOf(c) !== -1) Settings.difficulty = choices[parseInt(c,10)-1];
      }
      saveSettings(Settings);
    } else break;
  }
}

/* ---------------- High scores and menu ---------------- */
function showHighScores(){
  writeScoresAnsi();
  var scrollerPath = ART_DIR + "turtlebridge-scores.ans";
  if(typeof file_exists==="function" && file_exists(scrollerPath)){
    try { bbs.exec('?../xtrn/scroller/scroller.js "' + scrollerPath + '" "A-NET TURTLE BRIDGE - LOCAL LEADERBOARD" top'); return; }catch(e){ try{ bbs.exec('?scroller/scroller.js "' + scrollerPath + '" "A-NET TURTLE BRIDGE - LOCAL LEADERBOARD" top'); return; }catch(e2){} }
  }
  console.clear();
  console.print("TURTLE BRIDGE - Local Leaderboard\r\n\r\n");
  var lb = loadLeaderboard();
  if(!lb || lb.length === 0) console.print("No scores recorded yet.\r\n\r\n");
  else {
    for(var i=0;i<Math.min(lb.length,20);i++){
      var e = lb[i];
      console.print(fmtPadRight((i+1)+".",4) + fmtPadRight(e.alias,20) + fmtPadRight(String(e.score||0),8) + " " + (e.date||"").slice(0,10) + "\r\n");
    }
    console.print("\r\n");
  }
  console.print("Press any key..."); console.getkey();
}

function drawTitleHeader(){
  console.clear();
  console.gotoxy(1,1);
  var title = "A-NET TURTLE BRIDGE";
  var pad = Math.max(0, Math.floor((WIDTH - title.length) / 2));
  console.print(ANSI_BOLD + C_CYAN + repeatString(" ", pad) + title + repeatString(" ", pad) + ANSI_RESET + "\r\n\r\n");
  console.gotoxy(1, HEIGHT - 1);
  console.print("\x01gUse LEFT/RIGHT (or A/D) to move. P pause. Q quit.");
}

function showMainMenu(){
  drawTitleHeader();
  if(typeof DDLightbarMenu !== "undefined"){
    var menu = new DDLightbarMenu(5,3, Math.min(WIDTH-10,60), Math.min(HEIGHT-6,12));
    menu.Add("Play Turtle Bridge", 1);
    menu.Add("Instructions", 2);
    menu.Add("Settings", 3);
    menu.Add("High Scores", 4);
    menu.Add("Quit", 5);
    menu.colors.itemColor = "\x01k\x01h";
    menu.colors.selectedItemColor = "\x01b\x01h";
    menu.colors.borderColor = "\x01b";
    menu.AddAdditionalQuitKeys("qQ");
    menu.borderEnabled = true;
    menu.scrollbarEnabled = true;
    return menu.GetVal();
  } else {
    console.gotoxy(4,4); console.print("1) Play Turtle Bridge");
    console.gotoxy(4,5); console.print("2) Instructions");
    console.gotoxy(4,6); console.print("3) Settings");
    console.gotoxy(4,7); console.print("4) High Scores");
    console.gotoxy(4,8); console.print("5) Quit");
    console.gotoxy(1, HEIGHT); console.print("Choose [1-5]: ");
    var c = console.getkey();
    return c;
  }
}

/* ---------------- Main ---------------- */
function main(){
  ensureDirs();
  try{ if (typeof console !== "undefined" && typeof console.charset === "string") console.charset = "CP437"; }catch(e){}
  while(!js.terminated){
    var v = showMainMenu(); if(!v) break;
    var choice = (typeof v === "string") ? parseInt(v,10) : parseInt(v,10);
    var userNumber = (typeof user !== "undefined" && user && user.number) ? user.number : 9999;
    if(choice === 1) startTurtleBridge(userNumber);
    else if(choice === 2) showInstructions();
    else if(choice === 3) showSettingsMenu();
    else if(choice === 4) showHighScores();
    else break;
  }
}

/* ---------------- Run ---------------- */
try{ main(); }catch(err){ try{ console.print("\r\nFatal error: " + (err && err.toString ? err.toString() : String(err)) + "\r\n"); }catch(e){} }
